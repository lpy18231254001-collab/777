window.EXTRA=(window.EXTRA||"")+`
english|/ˈɪŋɡlɪʃ/|n.英语. adj.英格兰的.
problem|/ˈprɑːbləm/|n.问题. adj.有严重问题的.
academic|/ˌækəˈdemɪk/|adj.学术的，学业的，教学的. n.大 学教师.
hard|/hɑːrd/|adj.困难的. adv.努力地.
business|/ˈbɪznəs/|n.商业，生意.
real|/ˈriːəl/|adj.真的. adv.非常，很.
services|/ˈsɜːrvɪsɪz/|n.公共事业机构（或公司）.
under|/ˈʌndər/|prep.在…下面. adv.在下面. adj.下面 的，较低的.
plants|/pˈlɑnts/|n.(plural form of plant,plant 的复数 形式)植物，农作物. v.种植( plant 的第三 人称单数 ).
global|/ˈɡloʊbl/|adj.全球的.
ever|/ˈevər/|adv.在任何时候.
quality|/ˈkwɑːləti/|n.质量. adj.优质的.
whether|/ˈweðər/|conj. (表示选择或怀疑)是否. https://github.co
always|/ˈɔːlweɪz/|adv.总是.
process|/ˈprɑːses/|n.过程. v.加工.
value|/ˈvæljuː/|n.价值（观）. v.重视，珍视.
able|/ˈeɪbl/|adj.能（够）.
cannot|/ˈkænɑt/|=can not. om/liut969/CET
consumers|/kənˈsjuməs/|n.消费者，顾客( consumer 的名词 复数 ).
small|/smɔːl/|adj.小的. adv.小小地. n.细小部分， 腰部.
directions|/dɪˈrekʃnz/|n.direction 的复数形式.
live|/lɪv/|v.居住. adj.活的.
body|/ˈbɑːdi/|n.身体，躯干.
wellbeing|/ˌwelˈbiˌɪŋ/|n.健康，幸福.
tend|/tend/|v.往往会.
start|/stɑːrt/|v.开始. n.开端.
family|/ˈfæməli/|n.家（庭）. adj.家族的.
growing|/ˈɡroʊɪŋ/|adj.生长的. v.种植( grow 的现在分 词 ).
areas|/ˈeərɪrs/|地区，区域(area 的复数形式).
increase|/ɪnˈkriːs/|v.增加，增长. n.增加，增长.
away|/əˈweɪ/|adv.离开.
potential|/pəˈtenʃl/|adj.潜在的. n.潜力.
development|/dɪˈveləpmənt/|n.发展.
screen|/skriːn/|n.屏幕. v.放映.
far|/fɑːr/|adv.遥远地. adj.离得较远的.
provide|/prəˈvaɪd/|v.提供.
question|/ˈkwestʃən/|n.问题. v.问.
math|/mæθ/|n.数学（等于 mathematics）.
taking|/ˈtekɪŋ/|adj.迷人的. n.引人注目. v.拿（ take 的现在分词 ）.
off|/ɔːf/|prep.从…落下. adv.离开. adj.不新鲜 的. n.起跑. v.杀死.
employees|/ɛmˈplɔɪiz/|n.雇工，雇员（ employee 的名词复 数 ）.
possible|/ˈpɑːsəbl/|adj.做得到的. n.可能. https://github.co
already|/ɔːlˈredi/|adv.已经.
student|/ˈstuːdnt/|n.学生，大学生.
develop|/dɪˈveləp/|v.成长，发展.
having|/ˈhævɪŋ/|n.所有，持有. v.有( have 的现在分 词 ).
show|/ʃoʊ/|v.表明. n.演出. om/liut969/CET
ways|/ˈweɪz/|n.方法.
improve|/ɪmˈpruːv/|v.改进.
big|/bɪɡ/|adj.大的. adv.给人印象深地.
suggest|/səˈdʒest/|v.建议.
someone|/ˈsʌmwʌn/|pron.某人，有人. n.某个人.
decide|/dɪˈsaɪd/|v.决定.
hours|/ˈauəz/|n.小时( hour 的名词复数 ).
living|/ˈlɪvɪŋ/|adj.活（着）的. n.生活方式.
benefit|/ˈbenɪfɪt/|n.好处. v.获益.
stress|/stres/|n.精神压力. v.强调.
studies|/ˈstʌdɪz/|n.研究. v.学习，研究( study 的第三 人称单数 ).
means|/miːnz/|n.方法.
agriculture|/ˈæɡrɪkʌltʃər/|n.农业.
risk|/rɪsk/|n.风险，危险. v.冒风险.
history|/ˈhɪstri/|n.历史，历史学.
home|/hoʊm/|n.家. adj.家庭的. adv.在家.
telemedicine|/ˈtelɪˌmedɪsɪn/|n.（通过遥测、电话、电视等手段 求诊的）远距离医学.
knowledge|/ˈnɑːlɪdʒ/|n.知识.
early|/ˈɜːrli/|adj.早的. adv.在初期.
trying|/ˈtraɪɪŋ/|adj.令人难于忍受的. v.试图( try 的 现在分词).
during|/ˈdʊrɪŋ/|prep.在…期间（的某一时间）.
look|/lʊk/|v.看. n.看. int. （常为不悦时唤起他 人注意）喂，听我说.
longer|/ˈlɔŋɡə/|adj.比较久的.
major|/ˈmeɪdʒər/|adj.重要的. n.少校. v.主修.
word|/wɜːrd/|n.单词，字. v.措词，用词.
large|/lɑːrdʒ/|adj.大的. v.狂欢.
read|/riːd/|v.阅读，识字，读懂. n.阅读，读书. adj.博学的.
antarctic|/ænˈtɑːrktɪk/|adj.南极的，南极地区的. n.(A-)南极 洲.
end|/end/|n.最后部分. v.（使）结束.
behavior|/bɪˈheɪvjər/|n.行为，态度.
makes|/meɪks/|v.使( make 的第三人称单数 ).
called|/kɔːld/|v.叫( call 的过去式和过去分词 ). adj. 叫做；称作.
schools|/sˈkulz/|n.学校( school 的名词复数 ).
photos|/ˈfəʊtəʊz/|n.照片，相片( photo 的名词复数 ).
certain|/ˈsɜːrtn/|adj.肯定的. pron.某些（不提及人或 事物的名称时用）.
changing|/ˈtʃeɪndʒɪŋ/|n.替换.
set|/set/|v.放，置. n.一套/副/组. adj.位于… 的.
energy|/ˈenərdʒi/|n.精力，力气.
huge|/hjuːdʒ/|adj.巨大的.
pay|/peɪ/|v.付款. n.薪水.
diet|/ˈdaɪət/|n.日常饮食. v.节食. adj.有助减肥的.
decision|/dɪˈsɪʒn/|n.决定.
put|/pʊt/|v.放置.
never|/ˈnevər/|adv.从不. int. 不会吧.
effects|/ɪˈfekts/|n.动产，财物，家财.
group|/ɡruːp/|n.组，团体，集团. v.使成群，集合.
power|/ˈpaʊər/|n.权力. v.驱动. adj.电动的.
performance|/pərˈfɔːrməns/|n.表演. adj.性能卓越的.
actually|/ˈæktʃuəli/|adv.的确，事实上.
individual|/ˌɪndɪˈvɪdʒuəl/|adj.单独的. n.个人.
working|/ˈwɜːrkɪŋ/|adj.（涉及）工作的. v.（使）工作 ( work 的现在分词). n.工作.
place|/pleɪs/|n.地方. adv.到处. v.放置.
animal|/ˈænɪml/|n.动物，兽类. adj.动物的.
animals|/ˈænɪmlz/|n.动物( animal 的名词复数 ). https://github.co
cause|/kɔːz/|v.导致，引起. n.原因.
reading|/ˈriːdɪŋ/|n.阅读. v.读( read 的现在分词).
resources|/ˈriːsɔːrsɪz/|n.勇气.
almost|/ˈɔːlmoʊst/|adv.几乎，差不多.
face|/feɪs/|n.脸（面），面貌. v.面对，面临.
lower|/ˈloʊər/|adj.下方的. v.降低.
doctors|/ˈdɑktɚz/|n.医生，大夫( doctor 的名词复数 ).
focus|/ˈfoʊkəs/|v.集中. n.焦点.
lives|/lɪvz/|n.生命（life 的复数）. v.活（ live 的第三人称单数 ）.
friends|/frɛndz/|n.朋友( friend 的名词复数 ).
higher|/ˈhaɪər/|adj.高高的.
low|/loʊ/|adj.低的，矮小的. adv.低声地. n.低 点. vi.（牛）哞哞叫.
getting|/ˈɡetɪŋ/|n.获得（物），利益. v.得到( get 的 现在分词 ).
term|/tɜːrm/|n.学期. vt.把…称为.
field|/fiːld/|n.田地. adj.实地的. v.防守.
culture|/ˈkʌltʃər/|v.培植. n.文化.
workers|/ˈwɜkəz/|n.员工( worker 的名词复数 ).
since|/sɪns/|prep.自…以后. conj.自从. adv.后来.
though|/ðoʊ/|conj. 虽然，尽管. adv.不过，但是.
clear|/klɪr/|adj.易懂的，清楚的. v.理清. adv.一 直，径直.
population|/ˌpɑːpjuˈleɪʃn/|n.人口.
helps|/ˈhelps/|n.助手( help 的名词复数 ). v.帮助 ( help 的第三人称单数 ).
try|/traɪ/|v.尝试，努力. n.尝试，努力.
organic|/ɔːrˈɡænɪk/|adj.有机的.
writing|/ˈraɪtɪŋ/|n.文字（作品）. v.书写（write 的现 在分词）.
jobs|/dˈʒɒbz/|n.（一件）工作( job 的名词复数 ). om/liut969/CET
personal|/ˈpɜːrsənl/|adj.个人的.
team|/tiːm/|n.队，组. vi.协同工作.
traditional|/trəˈdɪʃənl/|adj.传统的，习俗的，惯例的.
control|/kənˈtroʊl/|n.统治. v.指挥.
common|/ˈkɑːmən/|adj.常见的. n.公共用地.
effect|/ɪˈfekt/|n.影响. v.使发生，引起.
really|/ˈriːəli/|adv.（表明事实或真相）事实上， 真正地，真实地；(强调观点等)确实，的 确；加强形容词或副词的语气.
identify|/aɪˈdentɪfaɪ/|vt.识别，认出. vi.确定.
average|/ˈævərɪdʒ/|adj.平均的. n.平均数. v.平均为.
benefits|/ˈbɛnəfɪt/|n.津贴费.
within|/wɪˈðɪn/|prep.在…之内/里. adv.在里面，在 内部.
marine|/məˈriːn/|adj.海洋的. n.海军陆战队士兵.
relationships|/rɪˈleɪʃnʃɪps/|n.（事物之间的）关系 ( relationship 的名词复数 ).
avoid|/əˈvɔɪd/|v.避免，防止.
cognitive|/ˈkɑːɡnətɪv/|adj.认知的.
mental|/ˈmentl/|adj.智力的.
wrote|/rot/|v.写( write 的过去式 ).
against|/əˈɡenst/|prep.反对.
here|/hɪr/|adv.在这里. int.喂.
million|/ˈmɪljən/|num. 百万.
local|/ˈloʊkl/|adj.本地的，地方的. n.本地人.
beyond|/bɪˈjɑːnd/|prep.在…另一边.
physical|/ˈfɪzɪkl/|adj.身体的. n.体格检查.
foods|/fudz/|abbr.foodstuff 粮食，食品. n.食物 ( food 的名词复数 ). https://github.co
books|/bʊks/|n.书( book 的名词复数 ). v.预订 ( book 的第三人称单数 ).
right|/raɪt/|adj.右边的. adv.向右. n.右边. v.矫正. int.（表示同意或遵从）是的，好的.
until|/ənˈtɪl/|prep.到…时.
money|/ˈmʌni/|n.钱.
art|/ɑːrt/|n.艺术（作品）. adj.艺术的. v.（be 的现在式单数第二人称形式，过时用法）.
kind|/kaɪnd/|n.种类. adj.体贴的.
conventional|/kənˈvenʃənl/|adj.传统的.
view|/vjuː/|n.看法，态度. v.把…视为，看待.
members|/ˈmembəz/|n.成员( member 的名词复数 ).
peers|/ˈpɪrz/|n.同等的人，贵族. vi.凝视，窥视. vt. 与…同等，封为贵族. v.凝视( peer 的第三 人称单数 ).
began|/bɪˈɡæn/|v.开始( begin 的过去式 ).
greater|/ɡreɪtə/|adj.大的(great 的比较级).
later|/ˈleɪtər/|adv.较晚地. adj.后来的.
access|/ˈækses/|n.入口，通道. v.访问，存取（计算 机信息）.
unfinished|/ʌnˈfɪnɪʃt/|adj.未做完的.
rice|/raɪs/|n.稻.
production|/prəˈdʌkʃn/|n.生产.
increasing|/ɪnˈkrɪsɪŋ/|v.增加，增大，增多( increase 的现 在分词 ).
simply|/ˈsɪmpli/|adv.仅仅.
sales|/seɪlz/|adj.销售的，推销的. n.销售（额）.
society|/səˈsaɪəti/|n.社会.
decades|/ˈdek.eɪdz/|n.十年，十年间( decade 的名词复 数 ).
enough|/ɪˈnʌf/|det. 足够. pron.足够. adv.充分地.
century|/ˈsentʃəri/|n.世纪.
costs|/ˈkɒsts/|n.讼费，诉讼费用. v.价钱为，花费 ( cost 的第三人称单数 ).
item|/ˈaɪtəm/|n.条，条款.
country|/ˈkʌntri/|n.国家.
factors|/ˈfæktərz/|n.因素( factor 的名词复数 ).
complex|/kəmˈpleks/|adj.复杂的. n.综合建筑群.
mind|/maɪnd/|n.思想. v.烦恼.
rise|/raɪz/|v.上升. n.上升.
retail|/ˈriːteɪl/|n.零售. vt.零售.
intelligence|/ɪnˈtelɪdʒəns/|n.聪颖.
cathedral|/kəˈθiːdrəl/|n.大教堂.
needs|/nidz/|adv.（现与 must 前后连用）必须， 一定，务必. v.需要，必须( need 的第三 人称单数 ).
driving|/ˈdraɪvɪŋ/|n.操纵，驾驶. adj.推进的. v.强迫 ( drive 的现在分词).
colleagues|/ˈkɑligz/|n.同事，同僚( colleague 的名词复 数 ).
success|/səkˈses/|n.成功.
started|/sˈtɑtɪd/|v.出发，启程( start 的过去式和过 去分词 ).
seem|/siːm/|v.好像，似乎，看来.
allowed|/əˈlaʊd/|adj.[计]容许的. v.允许( allow 的过 去式和过去分词 ).
identified|/aɪˈdentɪfaɪd/|v.认出( identify 的过去式和过去分 词 ).
city|/ˈsɪti/|n.城市.
me|/mi/|pron.（人称代词 I 的宾格）我. n.自 我.
build|/bɪld/|v.建造. n.体形.
hope|/hoʊp/|v.希望. n.希望.
income|/ˈɪnkʌm/|n.收入.
consumption|/kənˈsʌmpʃn/|n.消费，消耗量.
consider|/kənˈsɪdər/|v.认为，考虑.
lead|/liːd/|v.在…前面走. n.领先的地位.
women|/ˈwɪmɪn/|n.女人(woman 的复数). https://github.co
decisions|/dɪˈsɪʒənz/|n.决定( decision 的名词复数 ).
general|/ˈdʒenrəl/|n.将军. adj.全体的.
individuals|/ɪndɪˈvɪdʒʊrlz/|n.[口语]人（常指有趣或有点特别的 人）( individual 的名词复数 ).
carefully|/ˈkɛrfəlɪ/|adv.仔细地.
especially|/ɪˈspeʃəli/|adv.尤其.
customers|/ˈkʌstəməz/|n.[商业]客户( customer 的名词复 数 ).
bring|/brɪŋ/|v.带来.
various|/ˈveriəs/|adj.各种各样的.
along|/əˈlɔːŋ/|prep.沿着，顺着. adv.向前.
usually|/ˈjuːʒuəli/|adv.通常，经常，平常，惯常地.
looking|/ˈlʊkɪŋ/|adj.有…样子的，有…相貌的. v.看， 瞧( look 的现在分词 ).
results|/riˈzʌlts/|n.后果，结果（ result 的名词复 数 ）. v.发生（ result 的第三人称单数 ）.
recently|/ˈriːsntli/|adv.近来.
importance|/ɪmˈpɔːrtns/|n.重要（性）.
effective|/ɪˈfektɪv/|adj.有效的.
cultural|/ˈkʌltʃərəl/|adj.与文化/艺术有关的.
consequences|/ˈkɑnsə/|n.重要（性）( consequence 的名词 复数 ).
conditions|/kənˈdɪʃnz/|n.（居住、工作或做事情的）环境.
area|/ˈeriə/|n.地区，区域.
across|/əˈkrɔːs/|prep.穿过，横过. adv.从一边到另一 边.
reduce|/rɪˈduːs/|v.减少，缩小.
level|/ˈlevl/|n.水平. adj.齐平的. adv.靠近地. v.扳 平.
including|/ɪnˈkluːdɪŋ/|prep.包括. v.包括( include 的现在分 词).
plan|/plæn/|n.计划. v.计划.
relationship|/rɪˈleɪʃnʃɪp/|n.关系.
fishing|/ˈfɪʃɪŋ/|n.钓鱼.
contains|/kənˈteɪnz/|vt.(contain 的第三人称单数形式)， 包含，容纳. v.控制( contain 的第三人称 单数 ).
price|/praɪs/|n.价格. v.把…定价为.
despite|/dɪˈspaɪt/|prep.尽管，虽然.
play|/pleɪ/|n.比赛. v.玩.
present|/ˈpreznt/|adj.现在的，目前的. n.现在.
sea|/siː/|n.海（洋）.
project|/ˈprɑːdʒekt/|n.项目，工程. v.规划，计划.
half|/hæf/|n.一半. adv.部分地. det. pron.
easy|/ˈiːzi/|adj.容易的. adv.小心.
point|/pɔɪnt/|n.观点. v.指（向）向.
lack|/læk/|n.缺乏. v.缺少.
challenges|/ˈtʃælɪndʒ/|n.挑战( challenge 的名词复数 ).
debt|/det/|n.债务.
free|/friː/|adj.免费的. adv.免费. v.使摆脱.
ten|/ten/|num.十，十个. n.十个人.
list|/lɪst/|n.清单. v.列举.
programs|/pˈroʊɡræmz/|n.程序( program 的名词复数 ). v. （像计算机程序那样）预先确定 ( program 的第三人称单数 ).
buy|/baɪ/|v.购买，够支付. n.划算的东西.
full|/fʊl/|adj.满的. adv.直接地.
child|/tʃaɪld/|n.儿童，小孩.
drawing|/ˈdrɔːɪŋ/|n.素描（画），图画. v. 画; 移动; 拉，拖; 拔出（draw 的现在分词）.
hunting|/ˈhʌntɪŋ/|n.打猎. v.打猎(hunt 的现在分词).
taken|/ˈtekən/|v.拿( take 的过去分词).
ecological|/ˌiːkəˈlɑːdʒɪkl/|adj.生态（学）的.
community|/kəˈmjuːnəti/|n.社会（团体）.
waste|/weɪst/|v.浪费，滥用. n.浪费，滥用. adj.荒 芜的.
fire|/ˈfaɪər/|n.火（灾）. v.射击.
comes|/kʌmz/|n.伴星，伴引血管. v.来（ come 的 第三人称单数 ）.
south|/saʊθ/|n.南方. adj.南的. adv.向南方，在南 方.
due|/duː/|adj.预期的. n.应得的东西. adv.正对 着.
influence|/ˈɪnfluəns/|n.势力. v.影响.
activity|/ækˈtɪvəti/|n.活动，行动.
thought|/θɔːt/|n.思想. v.想（ think 的过去式和过 去分词）.
findings|/ˈfaɪndɪŋz/|n.发现物( finding 的名词复数 ).
turn|/tɜːrn/|v.（使）转动，旋转. n.转变.
america|/əˈmerɪkə/|n.美洲.
goals|/ˈɡoʊlz/|n.球门( goal 的名词复数 ).
program|/ˈproʊɡræm/|n.程序. v.[计]给…编写程序.
works|/wəks/|n.[机] 工厂，工场. v.（使）工作 （ work 的第三人称单数 ）.
follow|/ˈfɑːloʊ/|v.跟随.
days|/deɪz/|n.天，时期. adv.每天，在白天.
derived|/dɪˈraɪvd/|vi.起源. v.得到( derive 的过去式和 过去分词 ).
developed|/dɪˈvɛləpt/|adj.先进的.
earth|/ɜːrθ/|n.地球. v.把（电线）接地.
matter|/ˈmætər/|n.事情. v.要紧.
eat|/iːt/|v.吃（饭）.
created|/kriˈeɪtɪd/|adj.创造的. v.创造( create 的过去式 和过去分词 ).
ones|/ˈwʌnz/|n.二进制反码.
tell|/tel/|vt.告诉，说. vt.& vi.分辨，辨别. vi. 泄密，告发.
evidence|/ˈevɪdəns/|n.证据. v.证明.
americans|/əˈmerɪkənz/|n.美国人，美洲人（ American 的名 词复数 ）.
poor|/pʊr/|adj.贫穷的，贫乏的. n.the poor 贫 困者，穷人.
role|/roʊl/|n.角色. https://github.co
market|/ˈmɑːrkɪt/|n.集市. v.营销.
policy|/ˈpɑːləsi/|n.政策.
issues|/ˈɪʃjʊz/|n.（水等的）流出( issue 的名词复 数 ). v.出版( issue 的第三人称单数 ).
non|/nɒn/|adv.非，不. n.[法]反对票，投反对 票的人.
international|/ˌɪntərˈnæʃnəl/|adj.国际的. n.国际比赛.
meet|/miːt/|v.遇见. n.运动会.
times|/taɪmz/|乘以.
ask|/æsk/|v.（询）问.
side|/saɪd/|n.面，边. v.支持，偏袒.
creative|/kriˈeɪtɪv/|adj.有创造力的. n.搞创作的人.
similar|/ˈsɪmələr/|adj.类似的.
adults|/ˈædʌlts/|n.成年的人或动物( adult 的名词复 数 ).
test|/test/|n.试验. vt.测验. vi.受试验.
else|/els/|adv.其他的. om/liut969/CET
`;
