window.EXTRA=(window.EXTRA||"")+`
the|/ðə/|art.指已提到的人（物）.
to|/tu/|prep.向，朝着. adv.朝一个方向的. infinitive marker（表示目的或意图）, （表示结果）,（表示原因）,（表示想做…
of|/ʌv/|prep.关于.
and|/ənd/|conj.和，又.
in|/ɪn/|prep.采用（某种方式）. adv.在家. adj.在内的，朝内的.
it|/ɪt/|pron.它. n.<美俚>傻瓜，笨蛋.
is|/ɪz/|vt.& vi.是（be 的三单形式）.
that|/ðæt/|det.那个，那. pron.那个，那. conj. 多么. adv.不那么.
are|/ɑr/|vi.（用于第二人称单复数现在时， 第一、三人称复数现在时）是. n.公亩 （等于 100 平方米）.
they|/ðeɪ/|pron.他/她/它们.
on|/ɑːn/|prep.（表示方向）向. adv.（放， 穿，连接）上.
for|/fɔːr/|prep.为，为了. conj.因为，由于.
with|/wɪð/|prep.和. om/liut969/CET
their|/ðer/|det.他们的；她们的；它们的.
have|/hæv/|aux.用以构成完成式及完成式的不 定式，表示已经…. vt.有，具有. n.〈口〉 有产者，有钱人.
be|/bi/|v.有，存在. aux. 与过去分词连用构 成被动语态.
as|/æz/|prep.作为. adv.像. conj.当.
you|/jə/|pron.你，您.
more|/mɔːr/|adv.更，更多. pron.更多的或附加的 人或事物. n.更多.
from|/frəm/|prep.（表示时间）从….
by|/baɪ/|prep.被. adv.经过.
what|/wɑːt/|pron.什么. det.什么. conj.所. interj. 什么（事）. adv.（用于猜测）嗯，哦.
not|/nɑːt/|adv.不.
we|/wi/|pron.我们.
at|/æt/|prep.在.
people|/ˈpiːpl/|n.人，人类. vt.居住于，布满.
can|/kæn/|aux.能，可以. n.罐子. v.将…装罐保 存.
this|/ðɪs/|pron.这，这个. adv.这样地.
an|/æn/|art.一（在元音字母前代替不定代词 a）.
will|/wɪl/|v.将，会. n.意志，决心.
but|/bət/|conj.但是，然而. prep.除了. adv.只 有. n.借口.
was|//wəz/|v.用来表示某人或某物即主语本 身，用来表示某人或某物属于某一群体或 有某种性质（ be 的过去式 ）.
or|/ɔːr/|conj.或，或者. prep.<古、诗>在…之 前，比…更早. n.[纹章]黑金色、黑色.
about|/əˈbaʊt/|prep.关于，对于. adv.大约，左右. adj.现成的.
do|/duː/|v.做，干. aux.（用于实义动词前构 成否定句和疑问句）.
one|/wʌn/|num.（数字）一. n.一个人. pron.一 个人.
has|/hæz/|v.有( have 的第三人称单数 ).
when|/wen/|conj.当…时. pron.什么时候. adv.什 么时候.
than|/ðæn/|prep.比（用于比较级之后）. conj. 与其说，而不是.
passage|/ˈpæsɪdʒ/|n.通道，走廊. om/liut969/CET
he|/hiː/|pron.他，它. n.雄性动物.
them|/ðəm/|pron.他们.
based|/beɪst/|adj.有根基的. v.立基于.
questions|/ˈkwestʃənz/|n.询问，疑问，问题. v.问（某人） 问题( question 的第三人称单数 ).
there|/ðer/|adv.在那里. int.（表示满足、烦 恼）你瞧，好啦，得啦.
may|/meɪ/|aux.可以. n.[May]五月.
some|/səm/|det.一些. pron.一些. adv.大约.
just|/dʒʌst/|adv.刚才. adj.公正的，合理的.
she|/ʃiː/|pron.她，它.
who|/huː/|pron.谁.
if|/ɪf/|conj.如果，倘若. n.条件，设想.
time|/taɪm/|n.时间. vt.为…安排时间. vi.合拍.
our|/aʊər/|pron.我们的，we 的所有格形式.
should|/ʃʊd/|应该.
new|/nuː/|adj.新的，崭新的.
which|/wɪtʃ/|pron.哪一个. det.哪个.
her|/hər/|pron.她. 她的.
many|/ˈmeni/|adj.许多，多的. pron.（与复数动词 连用）大多数人.
all|/ɔːl/|det. 所有，全部，整个. pron.所有， 全部，一切. adv.完全.
each|/iːtʃ/|det.各自，每个. pron.各自，每个.
its|/ɪts/|det.（指事物、动物或婴儿）它 的，他的，她的.
his|/hɪz/|pron.(he 的所有格)他的. det.属于他 的，用于名词前.
how|/haʊ/|adv.怎样.
other|/ˈʌðər/|adj.其他的. pron.另外，其他.
were|/wə/|是，在（are 的过去式）. om/liut969/CET
answer|/ˈænsər/|v.回答，答复. n.回答.
does|/dʌz/|conj.做，有用，工作. v.做( do 的第 三人称单数 ). n.雌鹿（或雌兔、雌羚羊 等）( doe 的名词复数 ).
most|/moʊst/|adv.最，最多（大）. n.最大限度.
so|/soʊ/|adv.如此，这样. conj.因此.
through|/θruː/|prep.穿过，通过. adv.通过. adj.直达 的，直通的.
world|/wɜːrld/|n.世界. adj.举世瞩目的.
your|/jʊr/|det.你/您的.
children|/ˈtʃɪldrən/|n.孩子们(child 的复数).
been|/bɪn/|v.用来表示某人或某物即主语本 身，用来表示某人或某物属于某一群体或 有某种性质（ be 的过去分词 ）. om/liut969/CET
would|/wʊd/|modal.将，会（will 的过去式）.
says|/sez/|v.说，讲(say 的第三人称单数).
only|/ˈoʊnli/|adv.只有. adj.唯一的. conj. 不过.
like|/laɪk/|prep.像. v.喜欢. conj. 像…一样. n.喜 好. adj.相似的. adv.大概.
make|/meɪk/|v.制造. n.品牌.
also|/ˈɔːlsoʊ/|adv.而且.
work|/wɜːrk/|v.（使）工作，干活. n.工作，职业.
into|/ˈɪntə/|prep.进入，到…里面.
even|/ˈiːvn/|adv.甚至. adj.平坦的.
up|/ʌp/|adv.在上面，在高处. adj.向上的. vt.& vi.增加. prep.在…的上端.
social|/ˈsoʊʃl/|adj.社会的. n.联谊会.
heard|/hɝd/|v.听到，听见( hear 的过去式和过 去分词 ).
had|/həd/|v.有（ have 的过去式和过去分词 ）.
students|/ˈstudənts/|n.学生，大学生( student 的名词复 数 ). https://github.co
use|/juːs/|n.（使）用.
letter|/ˈletər/|n.信. vt.用字母标明. vi.写印刷体字 母.
could|/kʊd/|aux.“can”的过去式. modal verb 能，会，可以（can 的过去式）.
no|/noʊ/|interj.不，没有. n.反对票. adv.(用于 构成比较级的否定形式)根本不，毫不. det.没有.
life|/laɪf/|n.生活，生计.
those|/ðoʊz/|adj.& pron.that 的复数. adj.那些 的，那. n.那，那个( that 的名词复数).
over|/ˈoʊvər/|prep.在…的上方. n.一轮板球. adv.倒 下.
way|/weɪ/|n.方法，形式. adv.远远地.
these|/ðiːz/|adj.这些的. pron.这些.
out|/aʊt/|adv.出局. prep.（表示来源）从. vt. 使熄灭. n.不流行.
study|/ˈstʌdi/|v.学习. n.学习.
sheet|/ʃiːt/|n.床单.
part|/pɑːrt/|n.部分. v.离开. adv.部分地.
human|/ˈhjuːmən/|adj.人的. n.人.
much|/mʌtʃ/|adv.非常. pron.很多.
years|/ˈjɜz/|n.年( year 的名词复数 ).
such|/sʌtʃ/|adj.这样的. pron.这样. om/liut969/CET ion 3
section|/ˈsekʃn/|n.部分. v.切开.
any|/ˈeni/|det. 任何，任一. pron.任何数量. adv. 一点儿也（不），丝毫.
us|/əs/|pron.我们.
take|/teɪk/|v.拿，取. n.场景，镜头.
research|/ˈriːsɜːrtʃ/|n.研究，调查，探索. v.研究，探索.
food|/fuːd/|n.食物，食品.
because|/bɪˈkɔːz/|conj. 因为，由于.
change|/tʃeɪndʒ/|n.变化，变革. v.变化.
well|/wel/|adv.好，出色地. adj.健康的. int. （语气词）嗯，唔. n.井. v.涌出，冒出.
help|/help/|v.帮助，促进. n.帮助.
different|/ˈdɪfrənt/|adj.有差别的，分别的.
found|/faʊnd/|v.建立. v.发现，找到（find 过去 式）.
choices|/ˈtʃɔɪsɪs/|n.选择( choice 的名词复数 ). https://github.co
best|/best/|adj.最好的. n.最好的人/事. adv.最.
said|/sed/|adj.[律]上述的. v.说，讲( say 的过 去式和过去分词 ).
information|/ˌɪnfərˈmeɪʃn/|n.消息.
once|/wʌns/|adv.一次. conj. 一…就.
health|/helθ/|n.健康（状况）.
year|/jɪr/|n.年.
think|/θɪŋk/|v.想（到）.
better|/ˈbetər/|adv.更. adj.更好的. v.超越. n.更好的 事物. pron.更大成就.
corresponding|/ˌkɔːrəˈspɑːndɪŋ/|adj.相应的，相关的. v.符合.
author|/ˈɔːθər/|n.作者. v.创作，撰写. https://github.co
technology|/tekˈnɑːlədʒi/|n.科技.
making|/ˈmeɪkɪŋ/|n.制造. v.“make”的现在分词.
between|/bɪˈtwiːn/|prep.在…之间. adv.介于…之间.
science|/ˈsaɪəns/|n.科学.
line|/laɪn/|n.线条. v.沿…排列成行.
say|/seɪ/|vi.说， 讲. vt.表明. n.发言权.
following|/ˈfɑːloʊɪŋ/|adj.接下来的. n.追随者. prep.在…以 后.
learn|/lɜːrn/|v.学.
music|/ˈmjuːzɪk/|n.音乐.
often|/ˈɔːfn/|adv.常常. https://github.co
single|/ˈsɪŋɡl/|adj.单一的. n.单程票. v.选出.
first|/fɜːrst/|det.第一. pron.第一次. n.首例. adv. 最初.
get|/ɡet/|v.收到，获得.
minutes|/ˈmɪnɪts/|n.[法] 备忘录，会议记录，审判记 录.
two|/tuː/|n.两个. num.两个.
after|/ˈæftər/|prep.在…之后. conj. 在…以后. adv. 后来，以后. adj.后来的.
did|/dɪd/|v.做( do 的过去式).
long|/lɔːŋ/|adv.长时间地. adj.长的. v.渴望.
centre|/ˈsentər/|n.中心，核心. v.将…放在正中央.
less|/les/|adv.较少地，较小地. prep.减去. n. 较少，较小.
four|/fɔːr/|num.四.
being|/ˈbiːɪŋ/|n.生物. v.（用于说明原因的非限定 性从句中）因为.
parents|/ˈperənts/|n.双亲，父母（ parent 的名词复 数 ）. v.教养，引起（parent 的三单形 式）. n.（Parents）人名.
while|/waɪl/|conj.在…期间. n.一会儿.
others|/ʌðɚz/|n.别的( other 的名词复数 ).
why|/waɪ/|adv.为什么. conj.（用于从句句首） 为什么. int.哎呀，哟.
school|/skuːl/|n.学校. vt.训练，锻炼.
mark|/mɑːrk/|n.斑点，污渍. v.做记号.
too|/tuː/|adv.也.
both|/boʊθ/|det.两个. conj.不仅…而且….
university|/ˌjuːnɪˈvɜːrsəti/|n.综合性大学.
before|/bɪˈfɔːr/|prep.在…之前. conj.在…之前. adv.以 前.
need|/niːd/|v.需要. modal. 需要. n.必要.
own|/oʊn/|adj.自己的. v.有. pron.自己.
where|/wer/|conj.（在）. adv.在哪里.
same|/seɪm/|adj.同一的. pron.同一事物. adv.同 样，类似. om/liut969/CET
researchers|/ˈrɪsɜtʃəz/|n.研究员，调查者( researcher 的名 词复数 ).
now|/naʊ/|adv.现在，如今. conj.既然.
conversation|/ˌkɑːnvərˈseɪʃn/|n.交谈，谈话.
around|/əˈraʊnd/|prep.围绕. adv.大约.
learning|/ˈlɜːrnɪŋ/|n.学习，学识. https://github.co
education|/ˌedʒuˈkeɪʃn/|n.教育.
marked|/mɑːrkt/|adj.显著的，著名的. v.表示(mark 的过去分词).
future|/ˈfjuːtʃər/|n.未来. adj.未来的.
online|/ˌɑːnˈlaɪn/|adj.在线的.
given|/ˈɡɪvn/|adj.指定的，特定的. prep.考虑到， 鉴于. n.假设事实. om/liut969/CET
public|/ˈpʌblɪk/|n.平民. adj.公众的.
high|/haɪ/|adj.高的. n.最高点. adv.在高处.
then|/ðen/|adv.那时. adj.当时的.
might|/maɪt/|n.力气. modal 可能，可以（may 的 过去式）.
scientists|/ˈsaɪəntɪsts/|n.科学家( scientist 的名词复数 ).
words|/wɜdz/|n.字( word 的名词复数 ).
products|/pˈrɒdʌkts/|n.乘积( product 的名词复数 ).
feel|/fiːl/|v.感觉. n.触觉.
media|/ˈmiːdiə/|n.媒体.
used|/juːzd/|adj.习惯于，适应. v.使用，利用， 运用.
very|/ˈveri/|adv.很，非常. adj.恰好的，正是的.
without|/wɪˈðaʊt/|prep.缺乏，没有，不用. adv.没有， 缺乏.
become|/bɪˈkʌm/|v.成为，变得.
want|/wɑːnt/|v.需要，想要. n.想要的东西.
see|/siː/|vt.& vi.看（见），观看. n.主教教区.
bank|/bæŋk/|n.银行，库. v.存钱.
recent|/ˈriːsnt/|adj.近来的.
choice|/tʃɔɪs/|n.选择（权/范围）. adj.优选的.
space|/speɪs/|n.空间. v.以一定间隔排列.
environment|/ɪnˈvaɪrənmənt/|n.生活环境.
good|/ɡʊd/|adj.好的. n.好处. adv.好.
young|/jʌŋ/|adj.幼小的. n.年轻人.
likely|/ˈlaɪkli/|adj.可能的. adv.可能.
find|/faɪnd/|v.发现. n.(有价值的)发现.
another|/əˈnʌðər/|det. 另一个，又一个. pron.另一个， 又一个.
something|/ˈsʌmθɪŋ/|pron.某物，某事. adv.（与形容词连 用）很，非常.
ability|/əˈbɪləti/|n.能力.
according|/əˈkɔrdɪŋ/|n.协议，条约. v.给予（某种待遇）.
farmers|/ˈfɑməz/|n.农场主，农民( farmer 的名词复 数 ).
few|/fjuː/|adj. 很少的，几乎没有的. pron.很少. n.少数派.
data|/ˈdeɪtə/|n.数据.
government|/ˈɡʌvərnmənt/|n.政府.
write|/raɪt/|v.写（字/书/信）.
care|/ker/|v.关心，在意. n.小心.
last|/læst/|det. 最近过去的. adj.最近的. adv.上 次. pron.最后的人. v.持续. n.鞋楦.
going|/ˈgoʊɪŋ/|n.出行，离去. adj.活着的，现在的. v.进行(go 的现在分词).
keep|/kiːp/|v.保持. n.生活费用.
old|/oʊld/|adj.（多少）岁.
communication|/kəˌmjuːnɪˈkeɪʃn/|n.表达，交际.
positive|/ˈpɑːzətɪv/|adj.积极乐观的.
doing|/ˈduɪŋ/|n.做. v.做( do 的现在分词 ).
choose|/tʃuːz/|v.选择.
scientific|/ˌsaɪənˈtɪfɪk/|adj.科学（上）的.
day|/deɪ/|n.一天.
protein|/ˈproʊtiːn/|n.[化]朊，蛋白（质）.
recording|/rɪˈkɔːrdɪŋ/|n.记录，录音. v.记录，录音，拍摄 ( record 的现在分词).
yet|/jet/|adv.尚（未），还，仍. conj. 但是， 然而.
humans|/ˈhjumənz/|n.人，人类( human 的名词复数 ).
hear|/hɪr/|v.听见.
give|/ɡɪv/|v.交给. n.延展性.
impact|/ˈɪmpækt/|n.影响. v.对…有影响.
things|/θɪŋz/|n.（个人的）用品.
paragraph|/ˈpærəɡræf/|n.段落.
sense|/sens/|n.感觉官能（即视、听、嗅、味、 触五觉）. v.感觉到.
my|/maɪ/|det.我的.
language|/ˈlæŋɡwɪdʒ/|n.语言（表达）.
made|/meɪd/|v.使（make 的过去式和过去分 词）. …制造的；制作…的.
important|/ɪmˈpɔːrtnt/|adj.重要的.
experience|/ɪkˈspɪriəns/|n.经验. v.经历.
come|/kʌm/|v.来. int. 好啦.
self|/self/|n.自己. adj.同一的. vt.使自花授精. vi. 自花授精.
three|/θriː/|num.三. n.三岁.
percent|/pərˈsɛnt/|n.百分比. adj.每一百中. adv.每一百 中.
climate|/ˈklaɪmət/|n.气候.
still|/stɪl/|adv.仍然. adj.静止的. n.剧照.
great|/ɡreɪt/|adj.伟大的，杰出的. adv.[口语]很好 地. n.大人物们.
among|/əˈmʌŋ/|prep.为…所围绕.
negative|/ˈneɡətɪv/|adj.消极的. v.拒绝. n.底片.
least|/liːst/|adv.最少. det. 最小的. pron.最小的.
person|/ˈpɜːrsn/|n.人.
water|/ˈwɔːtər/|n.水. v.灌溉. https://github.co
countries|/ˈkʌntrɪz/|n.国家( country 的名词复数 ).
ai|/aɪ/|Anguilla 安格拉.
example|/ɪɡˈzæmpl/|n.例子.
age|/eɪdʒ/|n.年龄（段）. v.（使）变老，显老.
report|/rɪˈpɔːrt/|v.报告. n.报道. om/liut969/CET
understanding|/ˌʌndərˈstændɪŋ/|n.了解. adj.善解人意的.
state|/steɪt/|v.陈述. n.状态. adj.国家的.
industry|/ˈɪndəstri/|n.工业.
brain|/breɪn/|n.（头）脑. v.猛击…的头部.
themselves|/ðəmˈselvz/|pron.他[她，它]们自己. om/liut969/CET ion 6
number|/ˈnʌmbər/|n.数字. v.总计.
species|/ˈspiːʃiːz/|n.物种.
rather|/ˈræðər/|adv.相当. int. 当然！的确！.
go|/ɡoʊ/|v.走，去. n.轮到的机会.
attention|/əˈtenʃn/|n.注意（力）. int. 注意！立正！.
college|/ˈkɑːlɪdʒ/|n.大学.
thinking|/ˈθɪŋkɪŋ/|n.思考. adj.有思想的. v.“think”的现 在分词.
nature|/ˈneɪtʃər/|n.自然.
economic|/ˌiːkəˈnɑːmɪk/|adj.经济的.
natural|/ˈnætʃrəl/|adj.自然的. n.有天赋的人.
down|/daʊn/|prep.往…的下端. adv.往下. v.咽下. adj.悲伤. n.绒毛.
patients|/ˈpeɪʃənts/|n.患者( patient 的名词复数 ).
know|/noʊ/|v.知道.
every|/ˈevri/|det.每个. adj.全部的.
understand|/ˌʌndərˈstænd/|v.明白，理解.
job|/dʒɑːb/|n.工作.
today|/təˈdeɪ/|adv.（在）今天. n.今天，今日.
companies|/ˈkʌmpəniz/|n.公司( company 的名词复数 ).
instead|/ɪnˈsted/|adv.替代.
fact|/fækt/|n.事实.
however|/haʊˈevər/|adv.然而. conj. 不管怎样.
back|/bæk/|adv.向后，在后面. n.背部. adj.后面 的. v.资助，支持.
environmental|/ɪnˌvaɪrənˈmentl/|adj.环境的.
him|/hɪm/|pron.(he 的宾格)他. https://github.co
medical|/ˈmedɪkl/|adj.医学的. n.体检.
must|/mʌst/|modal. 必须. n.必须做的事.
company|/ˈkʌmpəni/|n.公司.
statements|/ˈsteɪtmənts/|n.声明( statement 的名词复数 ).
cost|/kɔːst/|n.费用. v.需付钱.
followed|/ˈfɒloʊd/|v.跟随，接着（ follow 的过去式和 过去分词 ）.
problems|/ˈprɑbləms/|n.问题( problem 的名词复数 ).
farming|/ˈfɑːrmɪŋ/|n.务农，耕作.
idea|/aɪˈdiːə/|n.想法.
american|/əˈmerɪkən/|n.美国人，美洲人. adj.美国的，美 洲的.
grass|/ɡræs/|n.草，青草. vt.用草覆盖. vi.渐渐被 草覆盖.
fed|/fɛd/|n.(F-)<美，非正>（美国）联邦政府 执法官员，（尤指）联邦调查局调查员. v. 喂养( feed 的过去式和过去分词 ).
little|/ˈlɪtl/|det. 少量的. pron.少量的. adv.微小 地. adj.小的. om/liut969/CET
lot|/lɑːt/|n.全部，整个. adv.（与形容词和副 词连用）很，非常. pron.大量，许多. det. 大量，许多.
changes|/ˈtʃeɪndʒɪz/|n.（会令人感兴趣或可喜的）变化 （ change 的名词复数 ）.
believe|/bɪˈliːv/|v.相信，信任.
`;
