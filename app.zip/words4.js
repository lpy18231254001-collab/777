window.EXTRA=(window.EXTRA||"")+`
thing|/θɪŋ/|n.事件，形势.
becoming|/bɪˈkʌmɪŋ/|adj.<正>（衣服等）相配的. v.变 为，成为( become 的现在分词 ).
several|/ˈsevrəl/|det. 几个. adj.各自的.
together|/təˈɡeðər/|adv.一起，共同. adj.自信的，精干 的.
please|/pliːz/|int. 请. v.使高兴. https://github.co
further|/ˈfɜːrðər/|adv.（空间距离）较/更远地. adj.更 多的. v.促进.
weight|/weɪt/|n.重量，分量，体重. v.加重量于.
current|/ˈkɜːrənt/|adj.当前的. n.(河、湖或海的)水流.
share|/ʃer/|v.共有，合用. n.（应得或应承担 的）一份.
interest|/ˈɪntrəst/|n.兴趣. v.使感兴趣.
difficult|/ˈdɪfɪkəlt/|adj.困难的.
internet|/ˈɪntərnet/|n.互联网. abbr.interconnection network, internetwork 互联网.
result|/rɪˈzʌlt/|n.结果. v.导致. int. 成功了！.
developing|/dɪˈvɛləpɪŋ/|adj.发展中的.
product|/ˈprɑːdʌkt/|n.产品.
system|/ˈsɪstəm/|n.体系，制度.
measures|/ˈmeʒəz/|n.程度. v.量( measure 的第三人称单 数 ).
islands|/ˈɑɪləndz/|n.岛，岛屿( island 的名词复数 ).
takes|/teks/|v.拿( take 的第三人称单数 ).
training|/ˈtreɪnɪŋ/|n.训练.
next|/nekst/|adj.下一个的. adv.紧接着. pron.最近 于…. n.下一个.
successful|/səkˈsesfl/|adj.成功的.
subjects|/ˈsʌbdʒɪkts/|n.主题( subject 的名词复数 ). v.提交 ( subject 的第三人称单数 ). om/liut969/CET
came|/kem/|v.来( come 的过去式 ).
book|/bʊk/|n.书，著作. v.预订，预约.
plant|/plænt/|n.植物，草木. vt.种植.
past|/pæst/|adj.过去的，以前的. n.过去，过往. prep.超过，超出. adv.经过，超过.
increased|/ɪnˈkrist/|adj.增加的，增强的. v.增加，增 大，增多( increase 的过去式和过去分 词 ).
per|/pər/|prep.由.
done|/dʌn/|adj.已完成的. int.（表示接受建议）. v.做( do 的过去分词).
facial|/ˈfeɪʃl/|n.面部护理，美容. adj.面部的.
class|/klæs/|n.课（堂），班（级）. v.把…归类. adj.一流的，优秀的. om/liut969/CET
growth|/ɡroʊθ/|n.发展，增加.
sometimes|/ˈsʌmtaɪmz/|adv.有时，间或.
increasingly|/ɪnˈkriːsɪŋli/|adv.不断增加地.
sleep|/sliːp/|vi.睡，睡觉. vt.为…提供床位. n.睡眠.
woman|/ˈwʊmən/|n.（成年）女子，女性.
rich|/rɪtʃ/|adj.富有的.
financial|/faɪˈnænʃl/|adj.财政的，财务的.
parts|/pats/|n.部( part 的名词复数 ).
responsibility|/rɪˌspɑːnsəˈbɪləti/|n.责任，义务.
actors|/ˈæktəz/|n.演员（尤指男演员）( actor 的名 词复数 ).
bilingual|/ˌbaɪˈlɪŋɡwəl/|adj.双语的，两种语言的，能说两种 语言的.
healthy|/ˈhelθi/|adj.健康的.
expensive|/ɪkˈspensɪv/|adj.昂贵的.
hand|/hænd/|n.手. v.传递.
game|/ɡeɪm/|n.游戏，运动. adj.受伤的，瘸的. v. 打赌，赌输赢.
whole|/hoʊl/|adj.全部的，整体的. n.全部，整体. adv.(表示强调)完全地.
advantage|/ədˈvæntɪdʒ/|n.有利条件. v.有利于.
network|/ˈnetwɜːrk/|n.网络. v.建立工作关系网.
creativity|/ˌkriːeɪˈtɪvəti/|n.创造性，创造力，创作能力.
allow|/əˈlaʊ/|v.允许.
short|/ʃɔːrt/|adj.短的，短暂的. adv.突然. n.短裤.
effort|/ˈefərt/|n.努力.
digital|/ˈdɪdʒɪtl/|adj.数码的. n.数字电视.
practice|/ˈpræktɪs/|n.常规. v.练习.
easily|/ˈiːzəli/|adv.容易地.
fast|/fæst/|adj.快的，迅速的. adv.快速，立即. v.禁食，斋戒. n.禁食期，斋戒期.
marking|/ˈmɑrkɪŋ/|n.标记，记号.
quite|/kwaɪt/|adv.很，相当.
create|/kriˈeɪt/|v.创造.
open|/ˈoʊpən/|v.打开. adj.开放的. n.户外.
again|/əˈɡen/|adv.还，再一次.
decline|/dɪˈklaɪn/|v.减少. n.下降，减少.
serious|/ˈsɪriəs/|adj.严重的.
stories|/ˈstɔriz/|n.故事( story 的名词复数 ).
guidelines|/ˈgaɪdˌlaɪnz/|n.指导方针.
wrong|/rɔːŋ/|adj.错误的，有问题/麻烦的. adv.错 误地. n.不义行为. v.不公正对待.
audience|/ˈɑːdiəns/|n.观众.
known|/noʊn/|adj.大家知道的. v.知道( know 的过 去分词 ).
doctor|/ˈdɑːktər/|n.医生，大夫. v.篡改，伪造.
feelings|/ˈfilɪŋs/|n.感情.
comprehension|/ˌkɑːmprɪˈhenʃn/|n.理解力.
satellite|/ˈsætəlaɪt/|n.卫星.
retailers|/ˈriteɪləz/|n.零售商，零售店( retailer 的名词 复数 ).
damage|/ˈdæmɪdʒ/|v.损坏. n.损坏.
beliefs|/bɪˈlifs/|n.信仰.
popular|/ˈpɑːpjələr/|adj.受喜爱的.
famous|/ˈfeɪməs/|adj.著名的，有名的.
ago|/əˈɡoʊ/|adv.以前.
enjoy|/ɪnˈdʒɔɪ/|v.享受.
participants|/pɑˈtɪsɪpənts/|n.参加者，参与者. adj.有份的，参 与的.
risks|/rɪsks/|n.危险（性）( risk 的名词复数 ).
form|/fɔːrm/|n.类型. v.形成，构成.
region|/ˈriːdʒən/|n.地区，行政区域.
shows|/ʃoʊz/|v.给…看( show 的第三人称单数 ).
professor|/prəˈfesər/|n.教授.
true|/truː/|adj.真正的. adv.真正地.
required|/rɪˈkwaɪəd/|adj.必须的，<美>（学科）必修的. v.要求( require 的过去式和过去分词 ).
methods|/ˈmeθədz/|n.method 的复数：方法.
issue|/ˈɪʃuː/|n.问题. v.发表，发布.
united|/juˈnaɪtɪd/|adj.统一的. v.（使）团结/联合 （unite 的过去式）.
action|/ˈækʃn/|n.行动，行为. v.采取行动.
management|/ˈmænɪdʒmənt/|n.经营.
five|/faɪv/|num.五.
week|/wiːk/|n.周，星期.
sharing|/ˈʃerɪŋ/|n.分配.
families|/ˈfæməlɪz/|n.家( family 的名词复数 ).
reality|/riˈæləti/|n.现实.
stay|/steɪ/|v.停留. n.停留，逗留（时间），做 客.
activities|/ækˈtɪvətɪs/|n.活动（ activity 的名词复数 ）.
creating|/kriˈeɪtɪŋ/|v.创造( create 的现在分词 ).
rate|/reɪt/|n.速度，进度. v.评估，评价.
lose|/luːz/|v.输掉.
meat|/miːt/|n.肉.
traffic|/ˈtræfɪk/|n.车流. v.非法买卖(毒品等). https://github.co
run|/rʌn/|vt.& vi.跑. n.奔跑. vi.（工作等）进 行. vt.使奔跑.
debris|/dəˈbriː/|n.残骸，碎片.
classical|/ˈklæsɪkl/|adj.传统的.
california|/ˌkæləˈfɔrnjə/|n.加利福尼亚州（美国一个州）.
left|/left/|adj.左边的，左侧的. n.左，左面. v. 离开（ leave 的过去式和过去分词）.
order|/ˈɔːrdər/|n.次序. v.命令.
terms|/tɜːrmz/|n.条款.
happen|/ˈhæpən/|v.发生，出现.
events|/ɪˈvents/|n.事件.
slow|/sloʊ/|adj.慢的. adv.慢速地. v.使放慢速度.
worth|/wɜːrθ/|adj.价值，值…钱. n.价值，意义，作 用.
key|/kiː/|n.钥匙. vt.键入. vi.使用钥匙. adj.关 键的. https://github.co
expect|/ɪkˈspekt/|v.预期.
computer|/kəmˈpjuːtər/|n.计算机，电脑.
systems|/sɪstəms/|n.[物理化学]系( system 的名词复 数 ).
machine|/məˈʃiːn/|n.机器，机械. vt.用机器制造，用机 器加工. vi.被机器切削.
paragraphs|/ˈpærəɡrɑfs/|n.段落( paragraph 的名词复数 ).
sure|/ʃʊr/|adj.肯定的，有把握的. adv.（表示 同意）当然.
offer|/ˈɔːfər/|v.提供. n.建议.
appear|/əˈpɪr/|v.看来，好像.
related|/rɪˈleɪtɪd/|adj.相关的.
robots|/ˈroʊbɒts/|n.机器人( robot 的名词复数 ).
critical|/ˈkrɪtɪkl/|adj.关键的.
uk|/ˌjuˈkeɪ/|abbr.联合王国（the United Kingdom）.
minds|/maɪndz/|n.想法( mind 的名词复数 ).
protect|/prəˈtekt/|v.保护.
conservation|/ˌkɑːnsərˈveɪʃn/|n.保护.
steel|/stiːl/|n.钢，钢铁. vt.包上或镀上钢.
emotions|/ɪˈmoʊʃənz/|n.情感，感情，激情( emotion 的名 词复数 ).
seen|/sin/|v.看见( see 的过去分词 ). https://github.co
plastic|/ˈplæstɪk/|n.塑料. adj.塑料的.
expected|/ɪkˈspektɪd/|adj.（用作定语）预期要发生的，期 待中的. v.期望( expect 的过去式和过去分 词 ).
tool|/tuːl/|n.器具，工具. vt.用工具给…加工. vi. 使用工具.
psychological|/ˌsaɪkəˈlɑːdʒɪkl/|adj.心理的.
perhaps|/pərˈhæps/|adv.可能. om/liut969/CET
goal|/ɡoʊl/|n.球门.
bad|/bæd/|adj.坏的. adv.很，非常. n.坏人，坏 事.
act|/ækt/|n.行为，行动. v.行动，表现.
protection|/prəˈtekʃn/|n.保护.
deep|/diːp/|adj.深的. adv.深深地. n.海洋.
seems|/simz/|v.好像，仿佛（ seem 的第三人称单 数 ）.
grow|/ɡroʊ/|v.生长.
produce|/prəˈduːs/|v.引起. n.农产品.
months|/mʌnθs/|n.月( month 的名词复数 ).
death|/deθ/|n.死（亡）.
call|/kɔːl/|v.称呼. n.打电话.
genetic|/dʒəˈnetɪk/|adj.遗传的.
model|/ˈmɑːdl/|n.模型. vt.& vi.做模特儿. vt.模仿.
chinese|/ˌtʃaɪˈniːz/|n.中国人. adj.中国的.
thousands|/ˈθaʊzndz/|n.数千( thousand 的名词复数 ).
address|/əˈdres/|n.地址，位置. v.写（收信人）姓名 地址.
nothing|/ˈnʌθɪŋ/|pron.没有什么. adv.一点都不像….
reason|/ˈriːzn/|n.原因. v.推理.
colleges|/ˈkɒlɪdʒɪz/|n.大学( college 的名词复数 ).
saying|/ˈseɪɪŋ/|n.谚语.
post|/poʊst/|n.邮政. v.邮寄.
case|/keɪs/|n.情况.
taxes|/ˈtæksɪz/|n.税，税额( tax 的名词复数 ).
awareness|/əˈwernəs/|n.意识.
throughout|/θruːˈaʊt/|prep.自始至终. adv.自始至终.
recovery|/rɪˈkʌvəri/|n.恢复.
phone|/foʊn/|n.电话. vt.& vi.打电话（给某人）.
challenge|/ˈtʃælɪndʒ/|n.挑战. v.对…怀疑.
everyone|/ˈevriwʌn/|pron.每人，所有人.
man|/mæn/|n.男人. vt.使振作. int.（表示惊讶、 气愤等）嘿，天哪.
unique|/juˈniːk/|adj.唯一的.
residents|/ˈrezɪdənts/|n.居民( resident 的名词复数 ).
insects|/ˈɪnsekts/|n.昆虫( insect 的名词复数 ).
travel|/ˈtrævl/|n.旅行. vi.旅行. vt.经过，通过.
dietary|/ˈdaɪɪˌtɛri/|adj.饮食的. n.规定的食物.
stores|/stɔːrz/|n.商店( store 的名词复数 ). https://github.co
marathon|/ˈmærəθɑːn/|n.马拉松赛跑. adj.马拉松式的.
lifelong|/ˈlaɪflɔŋ/|adj.毕生的，终身的.
variety|/vəˈraɪəti/|n.多种多样.
spoken|/ˈspoʊkən/|v.讲，谈（ speak 的过去分词 ）. adj.以某种方式说话的.
caused|/kɔzd/|v.引起；使发生（cause 的过去分 词）. om/liut969/CET
york|/jɔrk/|vt.（板球）使击球员出局.
differences|/ˈdɪfərənsiz/|n.差别( difference 的名词复数 ).
peer|/pɪr/|vi.凝视. n.同辈，同等的人.
older|/oʊldər/|adj.年长的.
picture|/ˈpɪktʃər/|n.照片，画像. vt.构想，想象. https://github.co
playing|/ˈpleɪɪŋ/|v.演奏( play 的现在分词 ).
associated|/əˈsoʊʃieɪtɪd/|vi.联系(associate 的过去式和过去 分词). adj.（用于联合企业的名称）联合 的.
quickly|/ˈkwɪkli/|adv.迅速地.
motivated|/ˈmoʊtɪveɪtɪd/|adj.有动机的，有目的的. v.作为…的 动机，激发，诱发( motivate 的过去式和 过去分词 ).
educational|/ˌedʒuˈkeɪʃənl/|adj.教育的.
strategy|/ˈstrætədʒi/|n.策略.
currently|/ˈkɜːrəntli/|adv.目前，当前.
prevent|/prɪˈvent/|v.阻碍.
reach|/riːtʃ/|v.到达. n.臂展.
building|/ˈbɪldɪŋ/|n.建筑（物）. v.建造.
trust|/trʌst/|n.信任. v.相信，信任.
mostly|/ˈmoʊstli/|adv.主要地.
trend|/trend/|n.趋势，倾向.
respect|/rɪˈspekt/|n.尊敬. v.尊重，仰慕.
goes|/goʊz/|v.进行（go 的第三人称单数）. n. （牌戏、下棋等中）轮到的顺序（go 的 复数形式）.
places|/ˈpleɪsɪz/|n.位( place 的名词复数 ).
extreme|/ɪkˈstriːm/|adj.极其的. n.极端.
earlier|/ˈɝlɪr/|adj.早期的，初期的. adv.早期 （地），初期（地）.
career|/kəˈrɪr/|n.生涯. v.疾驰. adj.就业的. https://github.co
recognition|/ˌrekəɡˈnɪʃn/|n.认识，识别.
image|/ˈɪmɪdʒ/|n.形象.
starting|/ˈstɑtɪŋ/|n.出发，开始. v.出发，启程( start 的现在分词 ).
essay|/ˈeseɪ/|n.短文. v.企图.
statement|/ˈsteɪtmənt/|n.说明.
asked|/æskt/|v.问( ask 的过去式和过去分词 ).
talk|/tɔːk/|v.说话，谈话. n.交谈，讨论.
towards|/tɔːrdz/|prep.向，朝，对着.
advice|/ədˈvaɪs/|n.劝告，忠告.
cut|/kʌt/|v.切割. n.伤口.
national|/ˈnæʃnəl/|adj.国家的. n.国民.
voice|/vɔɪs/|n.嗓音，说话声，歌声. v.表示，表 达.
step|/step/|v.迈步. n.脚步.
tech|/tek/|n.技术.
diversity|/daɪˈvɜːrsəti/|n.多样性，多元性.
continue|/kənˈtɪnjuː/|v.持续.
paper|/ˈpeɪpər/|n.纸. adj.书面的. v.给…贴墙纸.
failure|/ˈfeɪljər/|n.失败.
listening|/ˈlɪsənɪŋ/|adj.收听的，收听无线电广播的. v. 倾听( listen 的现在分词 ).
disaster|/dɪˈzæstər/|n.灾难.
video|/ˈvɪdioʊ/|n.磁带录像. vt.录像.
produced|/prəˈdjust/|adj.（叶子等）畸形伸长的，引长的. v.生产( produce 的过去式和过去分词 ).
air|/er/|n.空气. v.播放.
loss|/lɔːs/|n.损失.
krill|/krɪl/|n.磷虾.
king|/kɪŋ/|n.国王.
available|/əˈveɪləbl/|adj.可用的，可获得的.
specific|/spəˈsɪfɪk/|adj.明确的.
demand|/dɪˈmænd/|v.强烈要求. n.要求.
paid|/peɪd/|adj.有报酬的. v.付给( pay 的过去式).
amount|/əˈmaʊnt/|n.金额. v.共计. https://github.co
finding|/ˈfaɪndɪŋ/|n.调查发现/结果.
alone|/əˈloʊn/|adj.独自的. adv.独自.
mean|/miːn/|v.意思是. adj.吝啬的. n.中庸.
experts|/ˈɛkspɚts/|n.专家，能手( expert 的名词复数 ). om/liut969/CET
showed|/ʃod/|v.给…看( show 的过去式和过去分 词 ).
task|/tæsk/|n.工作，任务. vt.交给某人（任务）.
learned|/lɜːrnd/|adj.有学问的.
levels|/ˈlevəlz/|n.水平( level 的名词复数 ).
although|/ɔːlˈðoʊ/|conj. 虽然.
concerned|/kənˈsɜːrnd/|adj.忧虑的.
eating|/ˈiːtɪŋ/|v.吃，喝，吃饭（ eat 的现在分 词 ）. n.吃；饮食.
european|/ˌjʊrəˈpiːən/|adj.欧洲的，欧洲人的. n.欧洲人.
southern|/ˈsʌðərn/|adj.南方的，南部的.
land|/lænd/|n.陆地. v.（使）降落，着陆.
europe|/ˈjʊrəp/|n.欧洲.
main|/meɪn/|adj.主要的. n.主管道.
rest|/rest/|v.休息. n.休息.
wanted|/ˈwɑntɪd/|adj.受通缉的. v.缺少( want 的过去 式和过去分词 ).
luxury|/ˈlʌkʃəri/|n.奢侈，豪华.
pictures|/ˈpɪktʃərz/|n.<非正>（过时）电影院； 电影业. v.绘画( picture 的第三人称单数 ).
obesity|/oʊˈbisəti/|n.肥胖，过胖.
second|/ˈsekənd/|det. 第二（的）. adv.以第二名/位. n. 秒. v.赞成.
strong|/strɔːŋ/|adj.强的.
leading|/ˈliːdɪŋ/|adj.最重要的. n.行距.
got|/gɑt/|v.得到(get 的过去式和过去分词).
event|/ɪˈvent/|n.事件.
farm|/fɑːrm/|n.农场. v.耕种.
difference|/ˈdɪfrəns/|n.差别，差额.
stop|/stɑːp/|v.使停止. n.停留.
basic|/ˈbeɪsɪk/|adj.基础的，根本的.
machines|/məˈʃinz/|n.机器( machine 的名词复数 ).
scale|/skeɪl/|n.规模，等级. v.攀登.
employers|/ɪmpˈlɔɪəz/|n.雇主( employer 的名词复数 ).
went|/wɛnt/|v.进行( go 的过去式 ).
top|/tɑːp/|adj.（位置、级别或程度）最高的. n. 顶（端），表面. v.超过.
causes|/kɔzɪz/|n.原因( cause 的名词复数 ).
anything|/ˈeniθɪŋ/|pron.任何事物/事情. om/liut969/CET
subject|/ˈsʌbdʒɪkt/|n.话题. adj.主观的. v.提出.
prove|/pruːv/|v.原来是.
communities|/kəˈmjʊnəti/|n.团体( community 的名词复数 ).
efforts|/ˈefəts/|n.努力( effort 的名词复数 ).
robot|/ˈroʊbɑːt/|n.机器人.
interaction|/ˌɪntəˈrækʃən/|n.一起活动.
professional|/prəˈfeʃənl/|adj.专业的. n.专业人士.
spend|/spend/|v.花钱. n.花费.
behaviors|/bɪheɪˈvioʊz/|n.行为( behavior 的名词复数 ).
tools|/tul/|n.工具( tool 的名词复数 ).
shift|/ʃɪft/|v.转移. n.转移.
clothing|/ˈkloʊðɪŋ/|n.衣服，服装.
shown|/ʃoʊn/|v.给…看( show 的过去分词 ).
daily|/ˈdeɪli/|adv.每天. adj.一天的. n.日报.
recycling|/ˌriˈsaɪklɪŋ/|n.再循环. v.回收利用( recycle 的现 在分词 ).
blank|/blæŋk/|adj.空（白）的. n.空格，空白处. v. 突然忘掉.
musicians|/mjuˈzɪʃənz/|n.音乐家( musician 的名词复数 ).
cultures|/ˈkʌltʃəz/|n.文化( culture 的名词复数).
seven|/ˈsevn/|num.七. n.七.
type|/taɪp/|n.类型，种类. v.打字.
news|/nuːz/|n.新闻.
`;
