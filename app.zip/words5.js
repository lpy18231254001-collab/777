window.EXTRA=(window.EXTRA||"")+`
rising|/ˈraɪzɪŋ/|n.隆起. v.起义( rise 的现在分词 ).
office|/ˈɑːfɪs/|n.办公室.
approach|/əˈproʊtʃ/|v.接近，临近. n.方法，方式. https://github.co
involved|/ɪnˈvɑlvd/|adj.复杂难懂的. v.表明（某人参与 了罪行等）(involve 的过去式和过去分 词).
statistics|/stəˈtɪstɪks/|n.统计数字.
adolescents|/ædəˈlesnts/|n.青春期的，青少年的( adolescent 的名词复数 ).
presence|/ˈprezns/|n.出席.
designed|/dɪˈzaɪnd/|adj.有计划的，原意的. v.设计，绘 制( design 的过去式和过去分词 ).
regions|/ˈridʒənz/|n.地区( region 的名词复数 ).
latest|/ˈleɪtɪst/|adj.最近的. n.最新事物.
either|/ˈiː.ðər/|pron.（两者之中）任意一个. adv.也 （不）. det. (两者中的)每个.
motivation|/ˌmoʊtɪˈveɪʃn/|n.动力. https://github.co
discovered|/dɪˈskʌvɚd/|v.发现( discover 的过去式和过去分 词 ).
store|/stɔːr/|n.百货商店. v.保存.
desire|/dɪˈzaɪər/|n.愿望. v.渴望.
progress|/ˈprɑːɡres/|n.进步. v.进步.
breeding|/ˈbriːdɪŋ/|n.生育. v.生育( breed 的现在分词 ).
survive|/sərˈvaɪv/|v.生存，存活.
marketing|/ˈmɑːrkɪtɪŋ/|n.销售，经销，行销，商品销售业 务.
took|/tʊk/|v.拿( take 的过去式 ).
bear|/ber/|n.熊. v.忍受.
leads|/liːdz/|n.（盖屋顶用的）（薄）铅片； 铅 框. v.带路( lead 的第三人称单数 ).
spent|/spɛnt/|adj.用过的. v.用钱，花钱( spend 的 过去式和过去分词 ).
threat|/θret/|n.威胁.
showing|/ˈʃoʊɪŋ/|n.（电影、电视节目等的）展映. v. 给…看( show 的现在分词 ).
crops|/kˈrɒps/|n.作物( crop 的名词复数 ).
soil|/sɔɪl/|n.泥土. vt.弄脏，污辱. vi.变脏、受 污染或玷污的.
response|/rɪˈspɑːns/|n.答复.
largest|/ˈlɑrdʒəst/|adj.大的，多量的，大规模的( large 的最高级 ).
wo|/wo/|n.令马停住的声音.
needed|/ˈnidɪd/|v.需要，必须( need 的过去式和过 去分词 ).
translation|/trænzˈleɪʃn/|n.翻译.
courses|/ˈkɔsɪz/|n.课程，路线. https://github.co
brand|/brænd/|n.品牌. v.加污名于.
helping|/ˈhɛlpɪŋ/|n.（食物）的一份. v.帮助( help 的 现在分词 ).
account|/əˈkaʊnt/|n.账号；账目，账单. v.认为是.
survey|/ˈsɜːrveɪ/|n.调查，勘测. v.审察，测量.
census|/ˈsensəs/|n.人口普查.
measure|/ˈmeʒər/|v.衡量. n.措施.
french|/frentʃ/|adj.法国的，法国人的. n.法语.
gap|/ɡæp/|n.缺口.
economy|/ɪˈkɑːnəmi/|n.经济.
widely|/ˈwaɪdli/|adv.普遍地.
imagine|/ɪˈmædʒɪn/|v.想象.
enable|/ɪˈneɪbl/|v.使能够.
attitudes|/ˈætətjʊd/|n.态度( attitude 的名词复数 ).
source|/sɔːrs/|n.根源，本源. vt.（从…）获得. vi.原 料来源.
coming|/ˈkʌmɪŋ/|n.(新事物)来临. adj.即将发生的.
story|/ˈstɔːri/|n.故事，传说.
rights|/raɪts/|n.认股权. v.纠正( right 的第三人称 单数 ).
concern|/kənˈsɜːrn/|n.担心. v.影响.
considered|/kənˈsɪdəd/|adj.经过仔细考虑的. v.考虑 ( consider 的过去式和过去分词).
heart|/hɑːrt/|n.心.
remains|/rɪˈmeɪnz/|n.遗骨，遗体，残骸，残余，遗迹. v.留下( remain 的第三人称单数).
itself|/ɪtˈself/|pron.(it 的反身形式).
providing|/prəˈvaɪdɪŋ/|conj.如果. v.提供，供给，供应 ( provide 的现在分词).
majority|/məˈdʒɔːrəti/|n.多数. adj.多数人支持的.
emotional|/ɪˈmoʊʃənl/|adj.感情的.
arts|/arts/|n.文科.
analysis|/əˈnæləsɪs/|n.分析（报告）.
stock|/stɑːk/|n.股份，股票. adj.常备的，存货的. vt.提供货物. vi.出新芽.
brought|/brɔt/|v.带来( bring 的过去式和过去分词 ).
manufacturers|/mænjʊˈfæktʃərəz/|n.制造商，制造厂( manufacturer 的名词复数 ).
values|/ˈvæljʊz/|n.对价值的看法. v.估价( value 的第 三人称单数 ).
close|/kloʊz/|v.关闭. n.结束. adj.接近的. adv.不远.
fashion|/ˈfæʃn/|n.时尚（界）. v.制作，塑造.
exercise|/ˈeksərsaɪz/|n.练习. v.锻炼.
earthquake|/ˈɜːrθkweɪk/|n.地震.
ocean|/ˈoʊʃn/|n.洋.
india|/ˈɪndiə/|n.印度（亚洲）.
park|/pɑːrk/|n.公园. vi.泊车，停车. vt.将…放置在 某处.
dame|/dem/|n.夫人，女士.
automation|/ˌɔːtəˈmeɪʃn/|n.自动化.
enzyme|/ˈenzaɪm/|n.[生化]酶.
appeal|/əˈpiːl/|v.呼吁，恳请. n.呼吁，恳求.
war|/wɔːr/|n.战争.
service|/ˈsɜːrvɪs/|n.服务. v.检修，维护. adj.(大楼、建 筑中的设施）员工/后勤专用的.
teenagers|/ˈtinˌeɪdʒəz/|n.少年男女，青少年.
brains|/bˈreɪnz/|n.智力，脑髓.
advantages|/ədˈvæntɪdʒɪz/|n.有利条件( advantage 的名词复 数 ).
faster|/ˈfastə/|adj.更快的. adv.更快地.
condition|/kənˈdɪʃn/|n.状况. v.训练.
memory|/ˈmeməri/|n.记忆力.
range|/reɪndʒ/|n.一系列. v.变化，变动.
feeling|/ˈfiːlɪŋ/|n.感觉，感情. v.感觉.
limited|/ˈlɪmɪtɪd/|adj.有限的.
ready|/ˈredi/|adj.准备好的. v.为…作好准备. adv. 已完成. n.现钱.
series|/ˈsɪriːz/|n.一系列.
photo|/ˈfoʊtoʊ/|n.照片，相片. vt.& vi.（给…）拍照.
fatigue|/fəˈtiːɡ/|n.疲劳，厌倦.
biodiversity|/ˌbaɪoʊdaɪˈvɜːrsəti/|n.生物多类状态，生物多样性.
attend|/əˈtend/|v.出席，参加.
changed|/tʃeɪndʒd/|[医]变化的，改变的.
languages|/ˈlæŋɡwɪdʒɪz/|n.语言( language 的名词复数 ).
claimed|/klemd/|v.要求（应得权利）( claim 的过去 式和过去分词 ). om/liut969/CET
wild|/waɪld/|adj.野生的. n.自然环境.
weather|/ˈweðər/|n.天气（预报）. v.变色/形.
faces|/ˈfeɪsɪz/|n.面容( face 的名词复数 ). v.面对 ( face 的第三人称单数 ).
period|/ˈpɪriəd/|n.一段时间. adj.具有每个时代特征 的. adv.到此为止.
useful|/ˈjuːsfl/|adj.有用的，有益的，有帮助的.
greenhouse|/ˈɡriːnhaʊs/|n.温室.
millions|/ˈmɪlɪrnz/|n.数百万.
debate|/dɪˈbeɪt/|n.辩论. v.争论.
select|/sɪˈlekt/|v.选择，选拔. adj.精选的.
seniors|/ˈsinjəz/|n.高年级学生( senior 的名词复数 ).
graduates|/ˈgrædʒʊɪts/|n.<美>毕业生( graduate 的名词复 数 ). v.渐变( graduate 的第三人称单数 ).
welfare|/ˈwelfer/|n.幸福，安全与健康. adj.福利的.
existing|/ɪɡˈzɪstɪŋ/|adj.现行的，现存的.
raise|/reɪz/|v.提升，举起. n.加薪.
course|/kɔːrs/|n.课程，讲座. v.快速流动.
simple|/ˈsɪmpl/|adj.简单的.
status|/ˈsteɪtəs/|n.地位.
modern|/ˈmɑːdərn/|adj.现代的.
cold|/koʊld/|adj.（寒）冷的. n.（寒）冷. adv.突 然.
sources|/sɔːrsis/|n.（信息）来源( source 的名词复 数 ). v.（从…）获得.
unable|/ʌnˈeɪbl/|adj.不能…的.
include|/ɪnˈkluːd/|v.包括.
support|/səˈpɔːrt/|v.支持. n.支持.
australia|/ɔːˈstreɪliə/|n.[地名][大洋洲]澳大利亚，澳洲.
central|/ˈsentrəl/|adj.中心的.
solve|/sɑːlv/|v.解决.
interact|/ˌɪntərˈækt/|v.交流，互动.
capacity|/kəˈpæsəti/|n.容量. adj.座无虚席的.
productivity|/ˌprɑːdʌkˈtɪvəti/|n.生产率，生产力.
lie|/laɪ/|v.躺. n.谎言.
outside|/ˌaʊtˈsaɪd/|n.外面. adv.在外面. prep.在…之外. adj.外部的.
obvious|/ˈɑːbviəs/|adj.明显的.
interests|/ˈɪntrəsts/|n.兴趣( interest 的名词复数 ).
move|/muːv/|v.移动. n.行动.
remote|/rɪˈmoʊt/|adj.偏僻的，遥远的. n.遥控（器）.
require|/rɪˈkwaɪər/|v.需要.
electronic|/ɪˌlekˈtrɑːnɪk/|adj.电子的.
practices|/præktɪsɪz/|n.练习( practice 的名词复数 ).
tourists|/ˈtʊərɪsts/|n.旅行者，观光客( tourist 的名词 复数 ).
occur|/əˈkɜːr/|v.发生.
explain|/ɪkˈspleɪn/|v.解释.
jl|/dˈʒeɪˈel/|[医][=jadassohnlewandowsky(syndrome)]杰-柳二氏（综 合征）：先天性甲肥厚综合征. om/liut969/…
types|/ˈtaɪps/|n.类型. v.打字.
tax|/tæks/|n.税（款）. v.对…征税.
coral|/ˈkɔːrəl/|n.珊瑚（虫）. adj.珊瑚色的.
spanish|/ˈspænɪʃ/|adj.西班牙的. n.西班牙语.
special|/ˈspeʃl/|adj.特殊的. n.特制产品.
artificial|/ˌɑːrtɪˈfɪʃl/|adj.人造的.
kinds|/kaɪndz/|n.种类( kind 的名词复数 ).
lots|/lɒts/|n.签( lot 的名词复数 ).
eyes|/ˈaɪz/|n.眼睛（ eye 的名词复数 ）.
responsible|/rɪˈspɑːnsəbl/|adj.有责任的.
regardless|/rɪˈɡɑːrdləs/|adv.不顾后果地.
virtual|/ˈvɜːrtʃuəl/|adj.实质上的，事实上的.
speed|/spiːd/|n.速度. v.加速，快速前行.
effectively|/ɪˈfektɪvli/|adv.有效地.
socially|/ˈsoʃəlɪ/|adv.在社交方面.
track|/træk/|n.小道. v.跟踪.
giving|/ˈgɪvɪŋ/|n.礼物，给予物. v.给予，赠送( give 的现在分词 ).
whom|/huːm/|pron.谁（who 的宾格）.
stage|/steɪdʒ/|n.阶段. v.上演.
vital|/ˈvaɪtl/|adj.必要的，至关重要的.
pressure|/ˈpreʃər/|n.压力. v.强迫.
france|/fræns/|n.[地名]法国，法兰西.
beginning|/bɪˈɡɪnɪŋ/|n.开始. adj.刚入门的.
fields|/ˈfildz/|n.田( field 的名词复数 ). https://github.co
visitors|/ˈvɪzɪtəz/|n.访问者( visitor 的名词复数 ).
examples|/ɪɡˈzɑmplz/|n.例子.
advocates|/ˈædvəkeɪts/|n.（辩护）律师( advocate 的名词复 数 ). v.提倡( advocate 的第三人称单数 ).
habitats|/ˈhæbɪtæts/|n.（动物的）栖息地，住处( habitat 的名词复数 ).
aware|/əˈwer/|adj.知道的.
ecosystem|/ˈiːkoʊsɪstəm/|n.生态系统.
month|/mʌnθ/|n.月，月份.
completely|/kəmˈpliːtli/|adv.彻底地. v.全部完成. adj.全面的.
artists|/ˈɑtɪsts/|n.艺术家( artist 的名词复数 ).
instance|/ˈɪnstəns/|n.例子，实例. vt.举…为例.
held|/held/|v.拿（ hold 的过去式和过去分词 ）.
software|/ˈsɔːftwer/|n.（计算机）软件.
algorithms|/ˈælgəˈrɪðəmz/|n.运算法则( algorithm 的名词复数 ).
private|/ˈpraɪvɪt/|adj.私用的. n.列兵.
appropriate|/əˈprəʊpriət/|adj.适当的. v.私占.
upon|/əˈpɑːn/|prep.在…上.
translate|/trænzˈleɪt/|v.（翻）译. om/liut969/CET
name|/neɪm/|n.名字. v.给…取名.
belief|/bɪˈliːf/|n.信心，信任.
running|/ˈrʌnɪŋ/|n.跑步. adj.跑着的. v.跑.
race|/reɪs/|n.赛跑. v.参加比赛.
degree|/dɪˈɡriː/|n.级别. https://github.co
born|/bɔːrn/|v.出生. adj.天生的.
institutions|/ɪnstɪtˈjuʃnz/|n.（大学、银行等规模大的）机构 ( institution 的名词复数 ).
receive|/rɪˈsiːv/|v.收到，得到.
employment|/ɪmˈplɔɪmənt/|n.工作.
significant|/sɪɡˈnɪfɪkənt/|adj.重要的.
compare|/kəmˈper/|v.比较. n.举世无双.
perspective|/pərˈspektɪv/|n.透镜，望远镜. adj.（按照）透视 画法的.
topic|/ˈtɑːpɪk/|n.话题.
sustainable|/səˈsteɪnəbl/|adj.可持续的.
gas|/ɡæs/|n.气体. vt.加油. vi.加油.
rules|/ruːlz/|n.规程.
helpful|/ˈhelpfl/|adj.给予帮助的.
bath|/bæθ/|n.浴缸. v.（给小孩）洗澡.
agricultural|/ˌæɡrɪˈkʌltʃərəl/|adj.农业的，农用的.
advances|/ədˈvænsɪz/|n.接近，友好的表示，求爱. v. （使）前进( advance 的第三人称单数 ).
serve|/sɜːrv/|v.为…服务/效力. n.发球.
record|/ˈrekərd/|n.记录，记载. v.记录；记载. adj.创 纪录的.
interested|/ˈɪntrəstɪd/|adj.感兴趣的.
largely|/ˈlɑːrdʒli/|adv.大部分地，主要地.
moving|/ˈmuːvɪŋ/|adj.移动的，运动的. v.移动，转 变，前进，采取行动，搬家（move 的现 在分词）.
aim|/eɪm/|v.旨在. n.目标，意图.
contact|/ˈkɑːntækt/|n.联系，联络. v.联系，联络.
wide|/waɪd/|adj.宽的. adv.充分地. n.（板球）歪 球.
destruction|/dɪˈstrʌkʃn/|n.破坏.
allows|/əˈlaʊz/|v.允许( allow 的第三人称单数 ).
temperatures|/ˈtemprətʃəz/|n.温度( temperature 的名词复数 ).
esteem|/ɪˈstiːm/|v.尊重，敬重. n.尊重，敬重.
celebrities|/sɪˈlɛbrəti/|n.（尤指娱乐界的）名人( celebrity 的名词复数 ). https://github.co
fear|/fɪr/|n.恐惧. v.害怕.
pollution|/pəˈluːʃn/|n.污染.
tourism|/ˈtʊrɪzəm/|n.旅游业.
dairy|/ˈderi/|n.牛奶场. adj.牛奶的，乳制的.
structure|/ˈstrʌktʃər/|n.构造. v.系统安排.
wireless|/ˈwaɪərləs/|adj.无线的. n.无线电（收音机）.
skill|/skɪl/|n.技巧.
prepare|/prɪˈper/|v.把…准备好.
breaking|/ˈbreɪkɪŋ/|n.破坏，阻断. v.打破，折断，弄坏 ( break 的现在分词 ).
charge|/tʃɑːrdʒ/|v.收费. n.收费.
miles|/mailz/|n.英里( mile 的名词复数 ).
relevant|/ˈreləvənt/|adj.相关的.
details|/ˈdiːteɪlz/|n.详细资料.
probably|/ˈprɑːbəbli/|adv.大概，或许，可能.
powerful|/ˈpaʊərfl/|adj.有权力的.
speaking|/ˈspiːkɪŋ/|n.说话. adj.演讲的. v.讲，谈(speak 的现在分词 ).
therefore|/ˈðerfɔːr/|adv.因此. om/liut969/CET
selective|/sɪˈlektɪv/|adj.精心选择的.
told|/toʊld/|v.表明( tell 的过去式和过去分词 ).
overall|/ˌoʊvərˈɔːl/|adj.全面的. adv.全部. n.外套.
manager|/ˈmænɪdʒər/|n.经理.
technologies|/tɛkˈnɑlədʒi/|n.科技（总称）( technology 的名词 复数 ). https://github.co
immediate|/ɪˈmiːdiət/|adj.即刻的.
experiments|/ɪkˈspɛrəmənt/|n.实验( experiment 的名词复数 ).
provided|/prəˈvaɪdɪd/|conj.如果. v.提供，供给( provide 的 过去式和过去分词).
pleasure|/ˈpleʒər/|n.快乐，满足.
design|/dɪˈzaɪn/|v.设计. n.设计. om/liut969/CET
offering|/ˈɔːfərɪŋ/|n.提议. v.提供(offer 的 ing 形式).
trouble|/ˈtrʌbl/|n.问题，麻烦，困难. v.使烦恼，使 忧虑.
break|/breɪk/|v.破碎. n.休息，间歇.
dry|/draɪ/|adj.干（燥）的. v.（使）变干. n.干 燥. https://github.co
sufficient|/səˈfɪʃnt/|adj.足够的.
valuable|/ˈvæljuəbl/|adj.有价值的.
tough|/tʌf/|adj.棘手的. n.暴徒. v.坚持. adv.坚强 地.
seeds|/siːdz/|n.种子( seed 的名词复数 ).
attached|/əˈtætʃt/|adj.附加的，附属的. v.贴上，系， 附上( attach 的过去式和过去分词). om/liut969/CET
necessary|/ˈnesəseri/|adj.必要的. n.必需品.
begin|/bɪˈɡɪn/|v.开始，以…开头.
computers|/kəmˈpjutəz/|n.（电子）计算机，电脑 ( computer 的名词复数 ).
force|/fɔːrs/|v.强迫. n.暴力.
everything|/ˈevriθɪŋ/|pron.每件事，一切. https://github.co
visit|/ˈvɪzɪt/|v.看望，拜访. n.看望，访问，参观.
afford|/əˈfɔːrd/|v.买得起.
night|/naɪt/|n.夜.
leave|/liːv/|v.离开. n.假期.
complete|/kəmˈpliːt/|adj.完全的，完整的. v.使齐全.
boost|/buːst/|v.使增长，推动. n.帮助，激励.
managers|/ˈmænɪdʒəz/|n.经理，管理人( manager 的名词复 数 ).
total|/ˈtoʊtl/|n.总数. adj.总的. v.总数达.
improved|/ɪmˈpruːvd/|adj.改良的. v.改善，改进，提高 ( improve 的过去式和过去分词 ).
yourself|/jɔːrˈself/|pron.你/您/你们自己.
abilities|/əˈbɪlətiz/|n.能力( ability 的名词复数 ).
physicians|/fɪˈzɪʃnz/|n.医生，内科医生( physician 的名 词复数 ).
shared|/ʃerd/|adj.共享的，共用的.
physics|/ˈfɪzɪks/|n.物理学.
temperature|/ˈtemprətʃər/|n.温度.
rely|/rɪˈlaɪ/|v.依靠.
carbon|/ˈkɑːrbən/|n.碳.
governments|/ˈgʌvənmənts/|n.政府( government 的名词复数 ).
crisis|/ˈkraɪsɪs/|n.危机.
diseases|/dɪˈzizɪz/|n.疾病( disease 的名词复数 ).
wants|/ˈwɒnts/|n.需求，欲望，必需品. v.缺少 ( want 的第三人称单数 ).
nutrition|/nuˈtrɪʃn/|n.营养. https://github.co
opportunity|/ˌɑːpərˈtuːnəti/|n.机会.
director|/dəˈrektər/|n.导演.
ground|/ɡraʊnd/|n.地面，土地. vi.搁浅，停飞. vt.把… 放在地上. v.grind 的过去式和过去分词. adj.磨细的；磨碎的.
feedback|/ˈfiːdbæk/|n.反馈（意见）.
affect|/əˈfekt/|v.影响.
seek|/siːk/|v.寻找.
wealth|/welθ/|n.财富，财产.
revealed|/rɪˈvild/|v.显示( reveal 的过去式和过去分 词 ).
received|/rɪˈsivd/|adj.被一般承认的，被认为标准的. v. 收到( receive 的过去式和过去分词 ).
talent|/ˈtælənt/|n.人才，天才.
mistakes|/məˈsteks/|n.错误( mistake 的名词复数 ). v.弄 错，误解( mistake 的第三人称单数 ).
lost|/lɔːst/|adj.失去的. v.遗失，失去.
resilience|/rɪˈzɪliəns/|n.弹性.
habits|/ˈhæbɪts/|n.习惯( habit 的名词复数 ). om/liut969/CET
position|/pəˈzɪʃn/|n.位置. v.安放.
conducive|/kənˈduːsɪv/|adj.有助于…的.
worldwide|/ˌwɜːrldˈwaɪd/|adj.世界各地的. adv.世界各地地.
piece|/piːs/|n.块. v.组合资料（以便了解情况）.
movement|/ˈmuːvmənt/|n.运动. https://github.co
industries|/ˈɪndəstri/|n.工业( industry 的名词复数 ).
creation|/kriˈeɪʃn/|n.(宗教)创世.
`;
