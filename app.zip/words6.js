window.EXTRA=(window.EXTRA||"")+`
businesses|/ˈbɪznəsɪz/|n.事情( business 的名词复数 ).
partners|/ˈpɑːrtnərz/|n.舞伴( partner 的名词复数 ).
planet|/ˈplænɪt/|n.行星.
hundreds|/ˈhʌndrədz/|n.数百.
orbit|/ˈɔːrbɪt/|n.轨道. vt.& vi.在…轨道上运行，环 绕轨道运行. vi.盘旋. vt.绕轨道而行.
promote|/prəˈmoʊt/|v.促进.
critics|/kˈrɪtɪks/|n.批评家( critic 的名词复数 ).
lying|/ˈlaɪɪŋ/|n.说谎. adj.横卧的. vt.& vi.(lie 的现 在分词). v.位于( lie 的现在分词 ).
coast|/koʊst/|n.海滨. v.惯性滑行.
claim|/kleɪm/|v.声称. n.声称，主张.
milk|/mɪlk/|n.奶. vt.挤奶.
degradation|/ˌdeɡrəˈdeɪʃn/|n.堕落，落魄.
argue|/ˈɑːrɡjuː/|v.争论，争吵.
saving|/ˈseɪvɪŋ/|n.节省.
labels|/ˈleɪbəlz/|n.标签( label 的名词复数 ).
add|/æd/|v.添加，增加.
elderly|/ˈeldərli/|adj.年纪较大的.
red|/red/|adj.红色的. n.红色.
previous|/ˈpriːviəs/|adj.先前的. adv.在先；在…以前.
childhood|/ˈtʃaɪldhʊd/|n.童年.
north|/nɔːrθ/|n.北方. adj.北方的. adv.在北方.
tiny|/ˈtaɪni/|adj.极小的，微小的.
fully|/ˈfʊli/|adv.完全地.
light|/laɪt/|n.光. v.照亮. adj.天色亮的.
men|/men/|n.人( man 的名词复数 ).
became|/bɪˈkem/|v.变为，成为（ become 的过去 式 ）.
potentially|/pəˈtenʃəli/|adv.潜在地.
generally|/ˈdʒenrəli/|adv.笼统地.
interpersonal|/ˌɪntərˈpɜːrsənl/|adj.人与人之间的.
interactions|/ɪntəˈrækʃnz/|n.一起活动( interaction 的名词复 数 ).
seeking|/siːkɪŋ/|v.寻找，探寻( seek 的现在分词 ).
sides|/saɪdz/|n.侧.
search|/sɜːrtʃ/|n.搜索，检索. v.搜寻，查找.
moment|/ˈmoʊmənt/|n.片刻. om/liut969/CET
journal|/ˈdʒɜːrnl/|n.日记，日志.
nearly|/ˈnɪrli/|adv.几乎.
cell|/sel/|n.细胞.
eye|/aɪ/|n.眼睛. v.注视，细看.
aid|/eɪd/|n.援助，帮助. v.援助，资助.
plans|/pˈlænz/|n.计划( plan 的名词复数 ). v.计划， 打算，设计( plan 的第三人称单数 ).
teachers|/ˈtitʃərz/|n.教师（ teacher 的名词复数 ）.
views|/vˈjuz/|n.看( view 的名词复数 ).
essential|/ɪˈsenʃl/|adj.基本的. n.必需品.
forests|/ˈfɔrɪsts/|n.森林( forest 的名词复数 ).
expressions|/ɪkˈspreʃənz/|n.表情( expression 的名词复数 ).
collected|/kəˈlɛktɪd/|adj.镇定的. v.收集( collect 的过去式 和过去分词).
security|/sɪˈkjʊrəti/|n.保护措施.
africa|/ˈæfrəkə/|n.非洲. adj.非洲的.
drought|/draʊt/|n.久旱，旱灾.
rare|/rer/|adj.稀少的，罕见的.
adapt|/əˈdæpt/|v.（使）适应/适合.
extremely|/ɪkˈstriːmli/|adv.极端地.
era|/ˈɪrə/|n.时代.
reserve|/rɪˈzɜːrv/|v.保留. n.储备.
supply|/səˈplaɪ/|n.提供，供应（量）. v.供应，提供.
materials|/məˈtɪərɪrlz/|n.材料( material 的名词复数 ).
shape|/ʃeɪp/|n.形状，图形. v.塑造.
hit|/hɪt/|v.打. n.打.
safety|/ˈseɪfti/|n.安全（性）. adj.保障安全的.
farmer|/ˈfɑːrmər/|n.农民.
consumer|/kənˈsuːmər/|n.消费者.
pretty|/ˈprɪti/|adj.漂亮的. adv.很.
funding|/ˈfʌndɪŋ/|n.用发行长期债券的方法来收回短 期债券. v.提供资金.
staff|/stæf/|n.全体职工. v.任职于….
willing|/ˈwɪlɪŋ/|adj.愿意的，乐意的.
necessarily|/ˌnesəˈserəli/|adv.必要地.
bit|/bɪt/|n.有点儿. v.咬，蛰，叮.
practical|/ˈpræktɪkl/|adj.实际的. n.实验课.
grades|/ɡˈreɪdz/|n.（官阶、质量）等级( grade 的名 词复数 ). v.（官阶、质量）等级( grade 的第三人称单数 ).
teaching|/ˈtiːtʃɪŋ/|n.教学.
hiring|/ˈhaɪərɪŋ/|n.雇用，租赁. adj.雇用的，租赁的. v.聘用( hire 的现在分词 ).
candidates|/ˈkændɪdeɪts/|n.报考者( candidate 的名词复数 ).
predict|/prɪˈdɪkt/|v.预言.
graduate|/ˈɡrædʒuət/|n.大学毕业生. v.获得学位.
fewer|/ˈfjuə/|pron.（动词用复数）较少数. adj.较 少的.
patient|/ˈpeɪʃnt/|n.病人，患者. adj.有耐心的，能忍 耐的.
achieve|/əˈtʃiːv/|v.实现，达到.
otherwise|/ˈʌðərwaɪz/|adv.否则.
iv|/ˈaɪˈvi/|abbr.increase value 增值.
rapid|/ˈræpɪd/|adj.瞬间的.
extinction|/ɪkˈstɪŋkʃn/|n. 灭绝，消亡.
wildlife|/ˈwaɪldlaɪf/|n.野生生物.
ecosystems|/ˈiːkəʊsɪstəm/|n.<生>生态系统( ecosystem 的名词 复数 ).
contributed|/kənˈtrɪbjʊtid/|v.捐献( contribute 的过去式和过去 分词 ).
deal|/diːl/|n.交易，协议. v.经营，买卖.
harm|/hɑːrm/|v.伤害. n.伤害.
medicine|/ˈmedɪsn/|n.医学.
hill|/hɪl/|n.小山，山冈.
expand|/ɪkˈspænd/|v.扩大.
concerns|/kənˈsɜnz/|n.关系( concern 的名词复数 ).
indeed|/ɪnˈdiːd/|adv.确实.
commercial|/kəˈmɜːrʃl/|adj.商业（化）的. n.商业广告.
sensors|/ˈsensəz/|n.传感器，灵敏元件( sensor 的名 词复数 ).
comfortable|/ˈkʌmftəbl/|adj.舒适的.
discovery|/dɪˈskʌvəri/|n.发现.
communicate|/kəˈmjuːnɪkeɪt/|v.沟通.
attitude|/ˈætɪtuːd/|n.态度，看法.
environments|/enˈvaɪərənmənts/|n.环境( environment 的名词复数 ).
sports|/spɔts/|adj.有关运动的. n.运动( sport 的名 词复数 ).
patterns|/ˈpætənz/|n.榜样( pattern 的名词复数 ). v.模 仿( pattern 的第三人称单数 ).
middle|/ˈmɪdl/|n.中央. adj.当中的.
scores|/skɔrz/|n.大量，众多.
devices|/dɪˈvaɪsɪz/|n.设备.
painting|/ˈpeɪntɪŋ/|n.绘画. v.绘画（ paint 的现在分 词）.
feed|/fiːd/|v.饲养. n.（给婴儿）一次喂奶.
centuries|/ˈsentʃərɪz/|n.100 年，一世纪( century 的名词 复数 ). https://github.co
projects|/pˈrədʒekts/|n.项目( project 的名词复数 ). v.投射 ( project 的第三人称单数 ).
soon|/suːn/|adv.很快.
himself|/hɪmˈself/|pron.（反身代词）他自己.
entire|/ɪnˈtaɪər/|adj.全部的，整个的.
thoughts|/ˈθɔts/|n.思想( thought 的名词复数 ). om/liut969/CET
billion|/ˈbɪljən/|n.十亿.
thus|/ðʌs/|adv.所以，因此.
zone|/zoʊn/|n.地区，区域. v.将…划作特殊区域.
balance|/ˈbæləns/|n.均衡，平衡（能力）. v.比较，权 衡.
efficiency|/ɪˈfɪʃnsi/|n.效率. https://github.co
dean|/diːn/|n.院长.
encourage|/ɪnˈkɜːrɪdʒ/|v.鼓励.
six|/sɪks/|n.六. num.六.
connected|/kəˈnektɪd/|adj.有关的.
function|/ˈfʌŋkʃn/|n.功能. v.工作.
unhealthy|/ʌnˈhelθi/|adj.不健康的.
skin|/skɪn/|n.皮，皮肤. vt.剥皮，削皮. vi.使愈 合，长皮.
save|/seɪv/|v.救助. n.（守门员的）救球. prep. 除…之外. conj. 除了.
disease|/dɪˈziːz/|n.疾病.
opportunities|/ˌɒpəˈtjunɪtɪs/|n.机会( opportunity 的名词复数 ).
goods|/ɡʊdz/|n.货物.
behind|/bɪˈhaɪnd/|prep.在…后面. adv.在…后面. n.臀 部，屁股.
revenue|/ˈrevənuː/|n.税收.
reducing|/rɪˈdusɪŋ/|n.减轻体重法. v.换算( reduce 的现 在分词 ).
television|/ˈtelɪvɪʒn/|n.电视，电视机.
radio|/ˈreɪdioʊ/|n.无线电. vt.& vi.用无线电发送讯息.
late|/leɪt/|adv.晚，迟. adj.接近末期.
hour|/ˈaʊər/|n.小时，钟头.
actor|/ˈæktər/|n.演员.
organization|/ˌɔːrɡənəˈzeɪʃn/|n.组织（工作）.
workplace|/ˈwɜːrkpleɪs/|n.工作场所，车间.
rational|/ˈræʃnəl/|adj.神智清楚的.
aging|/ˈedʒɪŋ/|n.老化. v.使变老.
younger|/ˈjʌŋɡər/|n.年纪较小者. adj.较年轻的.
situation|/ˌsɪtʃuˈeɪʃn/|n.情况.
visual|/ˈvɪʒuəl/|adj.视觉的. n.视觉材料.
respond|/rɪˈspɑːnd/|v.回答，回复.
grounds|/ɡˈraʊndz/|n.庭院.
joseph|/ˈdʒozəf/|n.<古>连帽大氅.
ignore|/ɪɡˈnɔːr/|v.忽视.
intellectual|/ˌɪntəˈlektʃuəl/|adj.智力的. n.知识分子.
accept|/əkˈsept/|v.接受，接纳.
dual|/ˈduːəl/|adj.两部分的.
roof|/ruːf/|n.顶（部）. v.给…盖顶.
bacteria|/bækˈtɪriə/|n.细菌.
typical|/ˈtɪpɪkl/|adj.典型的.
fat|/fæt/|adj.肥的，胖的. n.脂肪.
oil|/ɔɪl/|n.油. vt.给…加油. vi.化成油.
messages|/ˈmesɪdʒɪz/|n.信息( message 的名词复数 ).
road|/roʊd/|n.路. vt.在…设置路障.
failed|/feld/|adj.失败了的，不成功的. v.在…中失 败( fail 的过去式和过去分词 ).
worry|/ˈwɜːri/|v.（使）担心，发愁. n.担心，发愁.
car|/kɑːr/|n.小汽车，轿车.
adult|/əˈdʌlt/|n.成年人. adj.成年的.
psychologist|/saɪˈkɑːlədʒɪst/|n.心理学家.
room|/ruːm/|n.房间. vt.租房，合住.
turned|/ˈtɜnd/|v.（使）转动( turn 的过去式和过去 分词 ).
experiment|/ɪkˈsperɪmənt/|n.实验. v.做实验.
engaged|/ɛnˈɡedʒd/|adj.（指厕所等）有人用的. v.与某 人订婚.
reported|/rɪˈpɔtɪd/|adj.据报告的，据报导的，据传闻的.
noted|/ˈnoʊtɪd/|adj.闻名的，著名的. v.注意，记下.
grade|/ɡreɪd/|n.等级. vt.安排. vi.属于…等级.
particularly|/pərˈtɪkjələrli/|adv.特别.
priority|/praɪˈɔːrəti/|n.优先，优先权.
enjoying|/endˈʒɔɪɪŋ/|v.享有( enjoy 的现在分词 ).
lab|/læb/|n.实验室，研究室.
psychology|/saɪˈkɑːlədʒi/|n.心理（学）.
enjoyable|/ɪnˈdʒɔɪəbl/|adj.有乐趣的.
conducted|/kənˈdʌktɪd/|vt.实施. vt.& vi.引导，带领. vi.指挥 乐队. v.引导（ conduct 的过去式和过去 分词 ）.
cite|/saɪt/|v.引用.
safe|/seɪf/|adj.安全的，不会受伤的. n.保险 柜，保险箱.
distance|/ˈdɪstəns/|n.距离. adj.远程的. v.使疏远.
hardly|/ˈhɑːrdli/|adv.几乎不.
fifth|/fɪfθ/|num.第五. n.五分之一.
leisure|/ˈliːʒər/|n.空闲时间.
contribute|/kənˈtrɪbjuːt/|v.捐献.
department|/dɪˈpɑːrtmənt/|n.（政府）部，司，局.
treated|/tritɪd/|adj.已处理过的，精制过的，加工过 的. v.处理( treat 的过去式和过去分词 ).
traits|/tˈreɪts/|n.人的个性，显著的特点，特征 ( trait 的名词复数 ).
calls|/ˈkɔlz/|n.调用. v.叫( call 的第三人称单数 ).
resurrection|/ˌrɛzəˈrɛkʃən/|n.<宗>耶稣复活.
reserves|/rɪˈzɜvz/|n.储量. v.保留[储备]某物( reserve 的第三人称单数 ).
recover|/rɪˈkʌvər/|v.康复.
switch|/swɪtʃ/|n.（电路的）开关，闸，转换器. v. 改变，转变.
models|/ˈmɒdlz/|n.模型( model 的名词复数 ).
studying|/ˈstʌdiɪŋ/|v.学习，研究( study 的现在分词 ).
massive|/ˈmæsɪv/|adj.巨大的.
recognize|/ˈrekəɡnaɪz/|vt.认出. vi.承认，确认.
sensitive|/ˈsensətɪv/|adj.体贴的.
accessible|/əkˈsesəbl/|adj.可进入/到达/使用的.
expectations|/ekspekˈteɪʃnz/|n.希望( expectation 的名词复数 ).
added|/ˈædɪd/|adj.更多的. v.加.
greatly|/ˈɡreɪtli/|adv.非常，极大地.
talking|/ˈtɔːkɪŋ/|n.谈话. om/liut969/CET
meanwhile|/ˈmiːnwaɪl/|adv.同时.
maybe|/ˈmeɪbi/|adv.也许.
campus|/ˈkæmpəs/|n.校园，校区.
dream|/driːm/|n.梦（想）. v.做梦.
pupils|/ˈpjuplz/|n.学生( pupil 的名词复数 ).
deceased|/dɪˈsist/|adj.<法，正>已故的，已死的. v. 死，死亡(decease 的过去式和过去分词).
connection|/kəˈnekʃn/|n.关系.
compared|/kəmˈpɛrd/|adj.比较的，对照的.
rates|/rets/|n.速度( rate 的名词复数 ). v.估价 ( rate 的第三人称单数 ).
count|/kaʊnt/|v.数数. n.总数.
head|/hed/|n.头. v.排在前头.
harmful|/ˈhɑːrmfl/|adj.有害的.
tum|/tʌm/|n.（弦乐器弹拨时所发出的）当的 一声.
ice|/aɪs/|n.冰. vt.& vi.（使）结冰. vt.结冰. vi. 结冰.
toward|/təˈwɒrd/|prep.对于. adj.即将来到的.
novel|/ˈnɑːvl/|n.小说. adj.新颖的.
son|/sʌn/|n.儿子.
legal|/ˈliːɡl/|adj.法律的.
gave|/ɡeɪv/|v.给予，赠送( give 的过去式 ).
watch|/wɑːtʃ/|v.看，注视，观察. n.表.
expert|/ˈekspɜːrt/|n.行家. adj.娴熟的.
realize|/ˈriːəlaɪz/|vt.实现. vt.& vi.变卖，赚得.
ill|/ɪl/|adj.有病的. n.困难. adv.恶劣地.
herd|/hɜːrd/|n.兽群. vt.& vi.群集，纠结. vt.放牧.
ensure|/ɪnˈʃʊr/|v.确保.
happening|/ˈhæpənɪŋ/|n.事件. adj.时髦的.
regulation|/ˌreɡjuˈleɪʃn/|n.管理. adj.规定的，必须穿戴的， 必须使用的.
pieces|/ˈpisɪz/|n.（尤指一套中的）一件（ piece 的名词复数 ）. v.凑合，修补，接合 （ piece 的第三人称单数 ）.
audiences|/ˈɔdɪrnsɪz/|n.观众，听众，读者( audience 的 名词复数 ).
adequate|/ˈædɪkwət/|adj.足够的.
gone|/gɔn/|adj.过去的. v.go 的过去分词. prep. 晚于；已过.
speak|/spiːk/|vt.& vi.讲，谈.
web|/web/|n.蜘蛛网.
fail|/feɪl/|v.失败. n.不及格.
putting|/ˈpʊtɪŋ/|v.放置（put 的现在分词）.
sciences|/ˈsaɪənsɪz/|n.科学( science 的名词复数 ).
below|/bɪˈloʊ/|prep.在…下面. adv.在下面.
hacker|/ˈhækər/|n.（电脑） 黑客.
argument|/ˈɑːrɡjumənt/|n.理由. n.[计]参数，更多的表示实 参，在部分翻译中被叫做引数.
met|/met/|v.相遇( meet 的过去式和过去分词 ).
foundation|/faʊnˈdeɪʃn/|n.基础.
learners|/ˈlɜnəz/|n.学习者，初学者，见习驾驶员 ( learner 的名词复数 ).
center|/ˈsentər/|n.中心，核心. v.将…放在正中央.
direct|/dəˈrekt/|adj.笔直的，径直的. v.把…指向，指 示. adv.直接地.
plane|/pleɪn/|n.水平. adj.平的，平坦的. vt.用刨刨 平. vi.鸟滑翔.
sitting|/ˈsɪtɪŋ/|n.（摆姿势让人画像或拍照的）一 次（时间）. v.（使）坐( sit 的现在分词 ).
solutions|/səˈluʃnz/|n.(solution 的复数形式)解答.
released|/rɪˈliːst/|v.释放( release 的过去式和过去分 词 ).
driven|/ˈdrɪvən/|adj.奋发努力的. v.驾驶（drive 的过 去分词）.
let|/let/|v.允许. n.擦网球.
built|/bɪlt/|v.build 的过去式和过去分词. combining form…建成的；…造的.
technological|/ˌteknəˈlɑːdʒɪkl/|adj.技术上的.
style|/staɪl/|n.方式. v.把…设计成.
keeps|/kiːps/|v.（使）保持， （使）继续( keep 的第三人称单数 ).
manage|/ˈmænɪdʒ/|v.管理，经营.
suggested|/səˈdʒestɪd/|adj.暗示的. v.建议( suggest 的过去 式和过去分词 ).
brick|/brɪk/|n.砖.
biggest|/bɪgɪst/|adj.大的，长大的.
expertise|/ˌekspɜːrˈtiːz/|n.专门技术，专门知识.
extra|/ˈekstrə/|adj.额外的. n.额外费用. adv.格外， 特别.
house|/haʊs/|n.房屋. v.给…提供住房.
amateur|/ˈæmətər/|n.业余爱好者/运动员. adj.业余（爱 好的）.
beings|/ˈbiɪŋz/|n.人.
sugar|/ˈʃʊɡər/|n.食糖. vt.在…加糖. vi.形成糖. int. （做了蠢事或出现差错时表示懊恼，用作 shit 的委婉语）哎呀，真是的.
spending|/ˈspendɪŋ/|n.开销，花费. v.用钱，花钱( spend 的现在分词 ).
cases|/keɪsɪz/|n.案例.
chance|/tʃæns/|n.可能性. adj.偶然的，意外的. v.偶 然发生.
truth|/truːθ/|n.真相，事实. om/liut969/CET
fault|/fɔːlt/|n.责任. v.发现错误.
lessons|/ˈlɛsnz/|n.功课( lesson 的名词复数 ).
beef|/biːf/|n.牛肉. v.不断抱怨.
supplements|/ˈsʌplɪmənts/|n.增补（物）( supplement 的名词 复数 ).
immediately|/ɪˈmiːdiətli/|adv.立即. conj. 即刻. om/liut969/CET on 30
proposed|/prəˈpoʊzd/|adj.被提议的，所推荐的. v.提议， 建议( propose 的过去式和过去分词 ).
vast|/væst/|adj.广阔的.
protected|/prəˈtektɪd/|v.保护( protect 的过去式和过去分 词 ).
financially|/faɪˈnænʃəlɪ/|adv.财政上，金融上，经济上.
explore|/ɪkˈsplɔːr/|v.在…探险.
chimp|/tʃɪmp/|n.（非洲）黑猩猩.
glenn|/ɡlɛn/|n.格伦.
mainly|/ˈmeɪnli/|adv.主要地.
italy|/ˈɪtəlɪ/|n.意大利（欧洲）.
sector|/ˈsektər/|n.部门.
connect|/kəˈnekt/|v.(使)连接/接通.
lay|/leɪ/|v.放置. v.平躺（lie 的过去式）. n.性 伴侣. adj.外行的.
felt|/fɛlt/|n.毛毡. v.摸索( feel 的过去式和过去 分词 ).
won|/wʌn/|v.获胜，战胜（ win 的过去式和过 去分词 ）.
apple|/ˈæpl/|n.苹果.
west|/west/|adj.西部的. adv.向西. n.西方.
points|/ˈpɔɪnts/|n.<英>（铁道的）道岔，转辙器.
dangerous|/ˈdeɪndʒərəs/|adj.危险的.
warning|/ˈwɔːrnɪŋ/|n.警示. adj.警告的;告诫的;引以为戒 的.
twice|/twaɪs/|adv.两遍，两次.
teens|/tiːnz/|n.十几岁.
`;
